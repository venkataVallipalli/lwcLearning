import { LightningElement, api, wire, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import getOpportunityStageData from '@salesforce/apex/OpportunityStageProgressController.getOpportunityStageData';
import updateOpportunityStage from '@salesforce/apex/OpportunityStageProgressController.updateOpportunityStage';
import STAGE_FIELD from '@salesforce/schema/Opportunity.StageName';
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import { notifyRecordUpdateAvailable } from 'lightning/uiRecordApi';


export default class OpportunityStageProgress extends LightningElement {
    @api recordId;
    @api buttonLabel;

    @track objectApiName;
    @track stages = [];
    @track currentStage = '';
    @track error;
    @track isLoading = false;
    

    @wire(getPicklistValuesByRecordType, { 
        objectApiName: "$objectApiName", 
        recordTypeId: '$recordTypeId' // Reactive parameter
    })
    wiredPicklistValues({ error, data }) {
        if (data) {
            // Access a specific field (e.g., Industry) from the returned collection
            let dataStages = data.picklistFieldValues["StageName"].values.map(item => ({
                label: item.label,
                value: item.value
            }));

            //.filter(pickval => pickval.value != 'Closed/Abandoned' && pickval.value != 'Won - Move-In' && pickval.value != 'Won - Historical'); // Exclude Closed stages

            this.stages = this.buildProgressSteps(dataStages, this.currentStage);
        } else if (error) {
            console.error('Error fetching picklist values:', error);
        }
    }
    
    /**
     * Wire method to get stage data
     */
    // @wire(getOpportunityStageData, { recordId: '$recordId' })
    wiredStageData() {

        getOpportunityStageData({ recordId: this.recordId }).then(data => {
            this.objectApiName = data.objectApiName;
            this.recordTypeId = data.record.RecordTypeId;
            this.currentStage = data.currentStage;
            this.error = undefined;
        })
        .catch(error => {
            this.error = error;
            this.stages = [];
            this.showErrorToast('Error loading stage data', this.getErrorMessage(error));
        });


        // const { data, error } = result;
        
        // if (data) {

        //     this.objectApiName = data.objectApiName;
        //     this.recordTypeId = data.record.RecordTypeId;
        //     this.currentStage = data.currentStage;
        //     this.error = undefined;

        //     // let self = this;
        //     // let objectApiName = data.objectApiName;
        //     // let recordTypeId = data.record.RecordTypeId;
        //     // let currentStage = data.currentStage;

        //     // setTimeout(function (p1,p2,p3) {
        //     //     this.objectApiName = p1;
        //     //     this.recordTypeId = p2;
        //     //     this.currentStage = p3;
        //     //     this.error = undefined;
                
        //     // }.bind(self), 1000, objectApiName, recordTypeId, currentStage);

        //     // getPicklistValuesByRecordType({ 
        //     //     objectApiName: this.objectApiName, 
        //     //     recordTypeId: this.recordTypeId
        //     // }).then(picklistData => this.wiredPicklistValues({ data: picklistData }))
        //     // .catch(picklistError => {
        //     //     console.error('Error fetching picklist values:', picklistError);
        //     //     this.showErrorToast('Error loading stage data', 'Failed to load picklist values');
        //     // });
        // } else if (error) {
        //     this.error = error;
        //     this.stages = [];
        //     this.showErrorToast('Error loading stage data', this.getErrorMessage(error));
        // }
    }


    /**
     * Wire to listen for record changes to refresh the component
     */
    @wire(getRecord, { recordId: '$recordId', fields: [STAGE_FIELD] })
    opportunityRecord;

    connectedCallback() {
        this.wiredStageData();
    }


    /**
     * Builds progress indicator steps from stage data
     */
    buildProgressSteps(stageList, currentStageValue) {
        if (!stageList || stageList.length === 0) {
            return [];
        }

        const currentIndex = stageList.findIndex(stage => stage.value === currentStageValue);
        
        return stageList.map((stage, index) => {
            let stepClass = 'slds-path__item';
            
            if (index < currentIndex) {
                stepClass += ' slds-is-complete';
            } else if (index === currentIndex) {
                stepClass += ' slds-is-current slds-is-active';
            } else {
                stepClass += ' slds-is-incomplete';
            }

            return {
                ...stage,
                class: stepClass,
                index: index,
                isCurrent: index === currentIndex,
                isClickable: index !== currentIndex
            };
        });
    }

    /**
     * Handles stage click event
     */

    handleStageClick(event) {
        event.preventDefault();

        this.selectedStageValue = event.currentTarget.dataset.value;
        this.selectedStageLabel = event.currentTarget.dataset.label;
    }

    updateButtonClick(event) {
        event.preventDefault();
        
        if(this.selectedStageValue == 'Closed/Abandoned' || this.selectedStageValue == 'Won - Move-In' || this.selectedStageValue == 'Won - Historical'){
            this.showErrorToast('Invalid Action', 'You cannot select this stage (' + this.selectedStageLabel + '). Please use the Wizard Actions button instead.', 'pester');
        }else {
            this.updateStage(this.selectedStageValue, this.selectedStageLabel);
        }
        
        // Don't allow clicking on the current stage
        // if (!this.selectedStageValue || this.selectedStageValue === this.currentStage) {
        //     return;
        // }

    }

    /**
     * Updates the opportunity stage
     */
    async updateStage(newStageValue, newStageLabel) {
        this.isLoading = true;

        try {
            await updateOpportunityStage({
                recordId: this.recordId,
                newStage: newStageValue
            });

            this.currentStage = newStageValue;

            // Refresh the wire adapters
            // await refreshApex(this.wiredStageDataResult);
            
            this.showSuccessToast('Stage Updated', `Stage has been updated to "${newStageLabel}"`);
            await notifyRecordUpdateAvailable([{ recordId: this.recordId }]);

        } catch (error) {
            this.showErrorToast('Error updating stage', this.getErrorMessage(error));
        } finally {
            this.isLoading = false;
        }
    }

    /**
     * Shows success toast notification
     */
    showSuccessToast(title, message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: 'success'
            })
        );
    }

    /**
     * Shows error toast notification
     */
    showErrorToast(title, message, mode = "sticky") {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: 'error',
                mode: mode
            })
        );
    }

    /**
     * Extracts error message from error object
     */
    getErrorMessage(error) {
        if (error.body && error.body.message) {
            return error.body.message;
        } else if (error.message) {
            return error.message;
        } else if (typeof error === 'string') {
            return error;
        }
        return 'An unknown error occurred';
    }

    /**
     * Determines if component has data to display
     */
    get hasStages() {
        return this.stages && this.stages.length > 0;
    }

    /**
     * Determines if component should show spinner
     */
    get showSpinner() {
        return this.isLoading;
    }
}