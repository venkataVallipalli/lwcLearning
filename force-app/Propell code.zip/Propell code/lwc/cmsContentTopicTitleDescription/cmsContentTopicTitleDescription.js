import { LightningElement, wire, api } from "lwc";
import { getRecord } from "lightning/uiRecordApi";

export default class CmsContentTopicTitleDescription extends LightningElement {
    @api recordId;
    @api Prefix;
    @api ShowDescription;
    topic;
    topicTitle;
    topicDescription;

    @wire ( getRecord, {recordId: "$recordId", fields: ["Topic.Name","Topic.Description"]} )
    wiredTopic ( {error, data }) {

        if (error) {
            let message = 'Unknown error';
            if (Array.isArray(error.body)) {
                message = error.body.map(e => e.message).join(', ');
            } else if (typeof error.body.message === 'string') {
                message = error.body.message;
            }

            console.log("CMS Title Log || error:" + message);

        } else if (data) {
            this.topicTitle = data.fields.Name.value;
            this.topicDescription = data.fields.Description.value;
            console.log("CMS Title Log || topicTitle: " + this.topicTitle);
            console.log("CMS Title Log || topicDescription: " + this.topicDescription);
        } 
    }
}