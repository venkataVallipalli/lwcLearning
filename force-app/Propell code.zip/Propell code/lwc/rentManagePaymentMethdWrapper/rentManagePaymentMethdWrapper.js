import { LightningElement, wire, api, track } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import PaymentMethodRefresh from '@salesforce/messageChannel/PaymentMethodRefresh__c';

export default class RentManagePaymentMethdWrapper extends LightningElement {

    @api
    recordId;

    @api
    flowApiName;

    @track
    showFlow = true;

    get pmFlowInputVariables() {
      return [
        {
          name: "recordId",
          type: "String",
          value: this.recordId
        },
      ];
    }

    @wire(MessageContext)
    messageContext;

    connectedCallback() {
        subscribe(this.messageContext, PaymentMethodRefresh, () => {
            this.showFlow = false;
            setTimeout(() => {
                this.showFlow = true;
            }, 100);
        });

        if(!this.flowApiName){
            this.flowApiName = 'RENT_Manage_Payment_Method';
        }
    }
}