import { LightningElement, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getReports from '@salesforce/apex/ReportController.getReportList';

const columns = [
    {
        type: 'button',
        typeAttributes: { label: 'Open Report', name: 'open_report', title: 'Click to Open Report' },
        cellAttributes: { alignment: 'left' },
        initialWidth: 150,
    },
    { label: 'Name', fieldName: 'Name', type: 'text', wrapText: true },
    { label: 'Description', fieldName: 'Description', type: 'text', wrapText: true },
];

export default class ServiceTicketReports extends NavigationMixin(LightningElement) {
    reports;
    columns = columns;

    @wire(getReports) // Replace 'getReports' with your Apex method to fetch the reports.
    wiredReports({ data, error }) {
        if (data) {
            this.reports = data;
        } else if (error) {
            // Handle the error
        }
    }

    handleRowAction(event) {
        const row = event.detail.row;
        if (event.detail.action.name === 'open_report') {
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                    recordId: row.Id,
                    actionName: 'view',
                },
            });
        }
    }
}