import { LightningElement } from 'lwc';

export default class interactiveMapFlowComponentIMG extends LightningElement {}