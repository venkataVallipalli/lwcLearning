import { LightningElement, api, track, wire } from 'lwc';
import zipFile from "@salesforce/resourceUrl/TheSuiteEliteMobileAppBundle";
import { NavigationMixin } from "lightning/navigation";

export default class CustomExpCloudTileMenu extends NavigationMixin(LightningElement) {

    @api
    imageNamePrefix;
    @api
    staticResourceName;
    @api
    numberOfImages;
    @api
    imageFormat;
    @api
    variant;
    @api
    tileRows;

    @track
    images;
    @track
    isTile;
    @track
    isCarousel;
    
    currentImageIndex;
    interval;

    // @track
    // isVariationHorizontal = false;
    // @track
    // isVariationVertical = false;
    // @track
    // isVariationText = false;

    connectedCallback(){

        this.isTile = this.variant == 'tile'; 
        this.isCarousel = this.variant == 'carousel';
    
        let rows = []; // applies to variant 'tile' only
        let row = [];
        let imagesPerRow = this.numberOfImages / this.tileRows; // applies to variant 'tile' only

        let images = [];

        for(let i=1; i<=this.numberOfImages; i++){
            let imageName = this.imageNamePrefix + i + "." + this.imageFormat;
            let imageUrl = zipFile + "/" + imageName;
            let image = {
                url: imageUrl,
                name: imageName
            };

            images.push(image);
            row.push(image);
                
            if(i % imagesPerRow == 0){
                rows.push( JSON.parse(JSON.stringify(row)) );
                row = [];
            }
        }

        if(row.length > 0){
            rows.push( JSON.parse(JSON.stringify(row)) );
        }
        this.rows = rows;

        this.images = images;
        this.currentImageIndex = 0;

        clearInterval(this.interval);
        // this.startAutoScrolling();
    }

    // startAutoScrolling(){
    //     let self = this
    //     this.interval = setInterval(function() {
            
    //         let imageIndex = self.currentImageIndex % self.numberOfImages;

    //         let imageWraps = self.template.querySelectorAll('.custom-carousel-image-wrap');
    //         let imageWrap = imageWraps[imageIndex];
    //         // imageWrap.scrollIntoView({ behavior: 'smooth', block: 'start' });

    //         imageWrap.scrollTo({
    //             top: 0,
    //             right: imageWrap.offsetWidth * imageIndex,
    //             behavior: 'smooth' // For smooth scrolling animation
    //         });

    //         self.currentImageIndex++;
    //     }.bind(self), 3000); // 3000 milliseconds = 3 seconds
    // }

    disconnectedCallback() { 
        clearInterval(this.interval);
    }


    handleCarouselImageClick(){}

}