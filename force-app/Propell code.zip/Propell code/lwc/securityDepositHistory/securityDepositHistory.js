import { LightningElement, api, track, wire } from 'lwc';
import getSecurityDepositHistoryForMember from '@salesforce/apex/SecurityDepositController.getSecurityDepositHistoryForMember';
import getSecurityDepositBalance from '@salesforce/apex/SecurityDepositController.getSecurityDepositBalance';
import hasNewSecurityDepositFeatures from '@salesforce/apex/SecurityDepositController.hasNewSecurityDepositFeatures';

export default class SecurityDepositHistory extends LightningElement {
    @api recordId;
    @api propertyId;
    @track securityDeposits = [];
    @track isLoading = true;
    @track securityDepositBalance;
    @track showComponent = false;

    get noDeposits() {
        return !this.isLoading && this.securityDeposits.length === 0;
    }

    get accordionLabel() {
        const formattedBalance = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(this.securityDepositBalance || 0);
        return `Security Deposit on Account: ${formattedBalance}`;
    }

    get hasBalance() {
        return this.securityDepositBalance > 0 && this.showComponent;
    }

    @wire(getSecurityDepositHistoryForMember, { memberId: '$recordId', propertyId: '$propertyId' })
    wiredSecurityDeposits({ error, data }) {
        this.isLoading = true;
        if (data) {
            this.securityDeposits = data.map(deposit => ({
                ...deposit,
                paymentDate: this.formatDate(deposit.Payment_Date__c)
            }));
            this.isLoading = false;
        } else if (error) {
            console.error('Error fetching security deposit history:', error);
            this.isLoading = false;
        }
    }

    @wire(getSecurityDepositBalance, { accountId: '$recordId' })
    wiredSecurityDepositBalance({ error, data }) {
        if (data !== undefined) {
            this.securityDepositBalance = data;
        } else if (error) {
            console.error('Error fetching security deposit balance:', error);
        }
    }

    @wire(hasNewSecurityDepositFeatures, { propertyId: '$propertyId' })
    wiredPropertyFeature({ error, data }) {
        if (data !== undefined) {
            this.showComponent = data;
            this.isLoading = false;
        } else if (error) {
            console.error('Error checking property features:', error);
            this.showComponent = false;
            this.isLoading = false;
        }
    }

    formatDate(dateString) {
        if (!dateString) return '';

        const dateParts = dateString.split('-');
        if (dateParts.length === 3) {
            const [year, month, day] = dateParts;
            return `${month}/${day}/${year}`;
        }
        return dateString;
    }
}