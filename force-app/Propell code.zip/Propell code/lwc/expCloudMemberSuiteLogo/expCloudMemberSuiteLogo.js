import { LightningElement, track } from 'lwc';
import getMemberImages from '@salesforce/apex/ExpCloudMemberSuiteLogoController.getMemberImages';
import defaultImageUrl from "@salesforce/resourceUrl/theSuiteEliteDefaultLogoPhoto";

export default class ExpCloudMemberSuiteLogo extends LightningElement {

        // @track
        // logoUrl;
        @track
        logoUrlBg;

        // @track
        // photoUrl;
        @track
        photoUrlBg;
    
        connectedCallback(){
        
            getMemberImages({
                
            }).then(results => {
                // this.logoUrl = results.logoUrl;
                // this.photoUrl = results.photoUrl;

                if(!results.logoUrl || results.logoUrl.length < 5){
                    results.logoUrl = defaultImageUrl;
                }

                if(!results.photoUrl || results.photoUrl.length < 5){
                    results.photoUrl = defaultImageUrl;
                }

                this.logoUrlBg = "background-image: url(" + results.logoUrl + ")";
                this.photoUrlBg = "background-image: url(" + results.photoUrl + ")";
            }).catch(err => console.log(err));
        
        }

}