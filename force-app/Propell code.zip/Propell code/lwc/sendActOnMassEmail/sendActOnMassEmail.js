import { LightningElement, api, track } from 'lwc';

export default class SendActOnMassEmail extends LightningElement {
    @track isLoading = false;
    @track showIframe = false;

    _selectedIds = new Set(); // Internal representation of selected IDs

    @api
    get selectedIds() {
        return [...this._selectedIds];
    }

    set selectedIds(value) {
        if (value) {
            this._selectedIds = new Set(value);
        }
    }

    handleRowSelection(event) {
        const selectedRows = event.detail.selectedRows;

        // Add new selected row IDs to the Set (preserves unique IDs)
        selectedRows.forEach(row => this.selectedIds.add(row.Id));
       
        // Remove deselected row IDs from the Set
        const allRowIds = this.recordsToDisplay.map(row => row.Id);
        allRowIds.forEach(id => {
            if (!selectedRows.some(row => row.Id === id)) {
                this.selectedIds.delete(id);  // Remove ID if not selected anymore
            }
        });
    }

    handleSendToVF() {
        const selectedIdsString = [...this.selectedIds].join(',');  // Convert Set to array and join
        console.log('-->'+this.selectedIds);
        console.log('++>'+this._selectedIds);
        if (this._selectedIds.size > 0) {
            this.isLoading = true;
            // Store selected IDs in localStorage or send to iframe
            localStorage.setItem('selectedRecordIds', JSON.stringify([...this.selectedIds]));

            // Show the iframe after storing the IDs
            this.showIframe = true;

            setTimeout(() => {
                // Once the iframe is displayed, send the selected data to VF page
                const vfWindow = this.template.querySelector("iframe").contentWindow;

                // Wait for the iframe to load before sending the message
                setTimeout(() => {
                    const currentOrigin = window.location.origin;
                    vfWindow.postMessage(selectedIdsString, `${currentOrigin}/apex/Contact_Sent_ActOn_Email_MassClone`);
                    // vfWindow.postMessage(selectedIdsString, 'https://suite--dev.sandbox.my.site.com/apex/Contact_Sent_ActOn_Email_MassClone');
                    this.isLoading = false;
                    this.selectedIds.clear();
                    const datatable = this.template.querySelector('lightning-datatable');
                if (datatable) {
                    datatable.selectedRows = [];  // Deselect rows
                }
                  
                }, 5000);  // Give some time for the iframe to load
           
            }, 2000);

        } else {
            alert('No records selected');
        }
    }
}