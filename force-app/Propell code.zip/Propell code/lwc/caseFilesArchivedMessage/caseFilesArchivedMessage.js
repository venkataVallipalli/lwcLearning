import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import FILES_ARCHIVED_FIELD from '@salesforce/schema/Case.Files_Archived__c';

export default class CaseFilesArchivedMessage extends LightningElement {
    @api recordId;


    @wire(getRecord, { recordId: '$recordId', fields: [FILES_ARCHIVED_FIELD] })
    case;

    get isFilesArchived() {
        return getFieldValue(this.case.data, FILES_ARCHIVED_FIELD);
    }
}