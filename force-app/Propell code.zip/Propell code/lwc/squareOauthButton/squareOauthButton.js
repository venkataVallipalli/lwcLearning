import { LightningElement, api, track } from 'lwc';
import getRecord from '@salesforce/apex/SquareOAuthCallback.getRecord';
import { RefreshEvent } from 'lightning/refresh';

export default class SquareOauthButton extends LightningElement {
    @api recordId;
    @api squareClientId = 'sandbox-sq0idb-hWg5UPD1rXgCNr6UZKfzbg';
    @api squareRedirectUri = 'https://suite--full.sandbox.my.site.com/squareup/services/apexrest/squareCallback';
    @api squareScope = 'MERCHANT_PROFILE_READ';
    @api squareAuthUrl = 'https://connect.squareupsandbox.com/oauth2/authorize';//'https://connect.squareup.com/oauth2/authorize';
    @api buttonLabel = 'Connect Square';
    @api customState;
    @api prompt = 'consent';

    @track isMerchantIdAvailable = false;

    @track errorMessage;
    @track isPolling = false;
    pollIntervalId;
    popupWindow;

    connectedCallback() {
        this.checkIfMerchantIdAvailable();
    }

    handleConnect() {
        this.errorMessage = undefined;

        if (!this.recordId) {
            this.errorMessage = 'This component must be placed on an Account record page.';
            return;
        }
        if (!this.squareClientId) {
            this.errorMessage = 'Square Client ID is required.';
            return;
        }
        if (!this.squareRedirectUri) {
            this.errorMessage = 'Square Redirect URI is required.';
            return;
        }

        const stateObject = {
            accountId: this.recordId,
            redirectUri: this.squareRedirectUri,
            timestamp: Date.now().toString(),
        };
        if (this.customState) {
            stateObject.custom = this.customState;
        }

        const state = encodeURIComponent(JSON.stringify(stateObject));
        const authUrl = this.buildAuthorizeUrl(state);
        // Open OAuth in a popup so we can poll the Account record in the background
        try {
            this.popupWindow = window.open(authUrl, 'SquareOAuth', 'width=700,height=800');
        } catch (e) {
            this.popupWindow = null;
        }
        if (!this.popupWindow) {
            // popup blocked or not available; fall back to full navigation
            window.location.assign(authUrl);
        } else {
            // start polling immediately and continue every 2 minutes
            this.startPolling();
        }
    }

    buildAuthorizeUrl(state) {
        const params = new URLSearchParams();
        params.append('response_type', 'code');
        params.append('client_id', this.squareClientId);
        params.append('session', 'false');  // for production only
        params.append('locale', 'en-US');
        params.append('scope', this.squareScope);
        params.append('state', state);

        return `${this.squareAuthUrl}?${params.toString()}`;
    }

    startPolling() {
        if (this.isPolling) return;
        this.isPolling = true;
        // immediate check, then every 2 minutes (120000 ms)
        this.pollOnce();
        this.pollIntervalId = window.setInterval(() => this.pollOnce(), 120000);
    }

    stopPolling() {
        if (this.pollIntervalId) {
            clearInterval(this.pollIntervalId);
            this.pollIntervalId = null;
        }
        this.isPolling = false;
    }

    handleCancel() {
        this.stopPolling();
        if (this.popupWindow && !this.popupWindow.closed) {
            try { this.popupWindow.close(); } catch (e) {}
        }
    }

    pollOnce() {
        if (!this.recordId) return;
        //const FIELDS = ['Account.Square_Merchant_Id__c'];
        getRecord({ recordId: this.recordId })
            .then(record => {
                const merchant = record && record.Square_Merchant_Id__c ? record.Square_Merchant_Id__c : null;
                if (merchant) {
                    // found merchant id — stop polling and close popup
                    this.stopPolling();
                    if (this.popupWindow && !this.popupWindow.closed) {
                        try { this.popupWindow.close(); } catch (e) {}
                    }

                    this.isMerchantIdAvailable = true;

                    // refresh the page to display all new Account field information
                    RefreshEvent.fire(this, { recordId: this.recordId });

                }
            })
            .catch(err => {
                this.errorMessage = 'Error checking Account for Square connection.';
                this.stopPolling();
            });
    }

    checkIfMerchantIdAvailable() {
        getRecord({ recordId: this.recordId })
            .then(record => {
                this.isMerchantIdAvailable = record && record.Square_Merchant_Id__c ? true : false;
            })
            .catch(err => {
                this.errorMessage = 'Error checking Account for Square connection.';
            });
    }

    disconnectedCallback() {
        this.stopPolling();
    }
}