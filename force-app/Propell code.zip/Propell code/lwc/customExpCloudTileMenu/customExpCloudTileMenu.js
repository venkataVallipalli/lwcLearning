import { LightningElement, api, track, wire } from 'lwc';
import getCommunityNavigationMenu from '@salesforce/apex/CustomExpCloudTileMenuController.getCommunityNavigationMenu';
import { NavigationMixin } from "lightning/navigation";
import MY_mark_black from "@salesforce/resourceUrl/MY_mark_black";
import MY_mark_saffron from "@salesforce/resourceUrl/MY_mark_saffron";
import fsc_For from '@salesforce/label/c.fsc_For';


export default class CustomExpCloudTileMenu extends NavigationMixin(LightningElement) {

    @api
    communitySiteName;
    @api
    menuName;
    @api
    menuVariation;

    @track
    menu;
    @track
    isVariationHorizontal = false;
    @track
    isVariationVertical = false;
    @track
    isVariationText = false;

    connectedCallback(){
    
        this.isVariationHorizontal = this.menuVariation == "horizontal";
        this.isVariationVertical = this.menuVariation == "vertical";
        this.isVariationText = this.menuVariation == "text";

        getCommunityNavigationMenu({
            communitySiteName: this.communitySiteName,
            menuName: this.menuName
        }).then(results => {
            this.menu = results;

            if(this.isVariationText){

                let MYmarks = [
                    MY_mark_saffron,
                    MY_mark_black
                ];
                let newMenuItems = [];

                this.menu.menuItems.forEach((mi, index) => {
                    let colorIndex = index % 4;
                    mi.class = "variationTextItem bg" + colorIndex;
                    mi.wrapperClass = "variationTextMenuItemWrapper variationTextMenuItemWrapper" + colorIndex; 

                    let myMarkIndex = index % MYmarks.length;
                    mi.myMarkUrl = MYmarks[myMarkIndex];

                    if(mi.actionValue){
                        newMenuItems.push(mi);
                    }
                });
                this.menu.menuItems = newMenuItems;
            }
        }).catch(err => console.log(err));
    
    }

    handleTileClick(e){
        let index = e.target.dataset.index;
        let menuItem = this.menu.menuItems[index]; // https://developer.salesforce.com/docs/atlas.en-us.apexref.meta/apexref/apex_connectapi_output_navigation_menu_item.htm
        
        if (menuItem.actionType === "ExternalLink") {
            this.navigateToExternalPage(menuItem);
        } else if (menuItem.actionType === "InternalLink") {
            this.navigateToInternalPage(menuItem);
        }

        console.log(menuItem);
    }

    navigateToExternalPage(menuItem) {
        const url = menuItem.actionValue;
        if(url.length <= 12){
            return;
        }
        if (menuItem.target === "CurrentWindow") {
            this[NavigationMixin.Navigate]({
                type: "standard__webPage",
                attributes: {
                    url: url
                }
            });
        } else if (menuItem.target === "NewWindow") {
            window.open(url, "_blank");
        }
    }

    navigateToInternalPage(menuItem) {
        let pageNameSplit = menuItem.actionValue.split("/");
        
        if(menuItem.actionValue.indexOf("/recordlist/") > 1){
            // list view page
            this[NavigationMixin.Navigate]({
                type: 'standard__objectPage',
                attributes: {
                    objectApiName: pageNameSplit[4],
                    actionName: "list"
                },
                state:{
                    filterName: pageNameSplit[5]
                }
            });
        }else{
            // internal page
            if(pageNameSplit.length == 6){
                // list view page
                this[NavigationMixin.Navigate]({
                    type: 'standard__objectPage',
                    attributes: {
                        objectApiName: pageNameSplit[4],
                        actionName: "list"
                    },
                    state:{
                        filterName: pageNameSplit[5]
                    }
                });
            }else{
                // Handle specific menu items
                let pageName = pageNameSplit[pageNameSplit.length - 1];
                console.log('Navigating to:', pageName);
                
                let targetUrl;
                switch(pageName) {
                    case 'my-web-page':
                        targetUrl = '/my-account/my-web-page';
                        break;
                    case 'payments':
                        targetUrl = '/my-account/payments';
                        break;
                    case 'service-tickets':
                        targetUrl = '/my-account/service-tickets';
                        break;
                    case 'documents':
                        targetUrl = '/my-account/documents';
                        break;
                    case 'my-feedback':
                        targetUrl = '/my-account/my-feedback';
                        break;    
                    default:
                        targetUrl = '/' + pageName;
                }
                
                console.log('Target URL:', targetUrl);
                this[NavigationMixin.Navigate]({
                    type: 'standard__webPage',
                    attributes: {
                        url: targetUrl
                    }
                });
            }
        }
    }
}