import { LightningElement, wire } from 'lwc';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getDirectoryListingsForCurrentUser from '@salesforce/apex/ClientConnectController.getDirectoryListingsForCurrentUser';
import ID_FIELD from '@salesforce/schema/Directory_Listing__c.Id';
import OPTIN_FIELD from '@salesforce/schema/Directory_Listing__c.Matchmaker_OptIn__c';

export default class ClientConnectManager extends LightningElement {
    listings; 
    error;
    isLoading = false;
    
    connectedCallback() {
        this.loadListings();
        document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
    }

    disconnectedCallback() {
        document.removeEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
    }

    handleVisibilityChange() {
        if (!document.hidden) {
            this.refreshData();
        }
    }

    async loadListings() {
        this.isLoading = true;
        try {
            const data = await getDirectoryListingsForCurrentUser();
            this.listings = data.map(listing => ({
                ...listing,
                initialOptInState: listing.Matchmaker_OptIn__c,
                hasUnsavedChanges: false,
                isSaveDisabled: true
            }));

            this.error = undefined;
        } catch (error) {
            this.error = error.body.message;
            this.listings = undefined;
            console.error('Error loading listings:', error);
        } finally {
            this.isLoading = false;
        }
    }

    async refreshData() {
        await this.loadListings();
    }

    // Getter to check if listings array is empty
    get hasNoListings() {
        return this.listings && this.listings.length === 0;
    }

    // Getter to check if listings array has content
    get hasListings() {
        return this.listings && this.listings.length > 0;
    }

    // Method to check if a listing has unsaved changes
    isListingUnchanged(listingId) {
        const listing = this.listings?.find(item => item.Id === listingId);
        return listing ? listing.Matchmaker_OptIn__c === listing.initialOptInState : true;
    }

    // Getter method to check if save button should be disabled for a listing
    getSaveButtonDisabled(listingId) {
        const listing = this.listings?.find(item => item.Id === listingId);
        return listing ? listing.isSaveDisabled : true;
    }

    // --- Action Handlers ---
    handleCheckboxChange(event) {
        const listingId = event.target.dataset.id;
        const isChecked = event.target.checked;
        
        const listingIndex = this.listings.findIndex(item => item.Id === listingId);
        if (listingIndex !== -1) {
            const updatedListings = [...this.listings];
            const listingToUpdate = { ...updatedListings[listingIndex] };
            
            listingToUpdate.Matchmaker_OptIn__c = isChecked;
            listingToUpdate.hasUnsavedChanges = isChecked !== listingToUpdate.initialOptInState;
            listingToUpdate.isSaveDisabled = !listingToUpdate.hasUnsavedChanges;
            
            updatedListings[listingIndex] = listingToUpdate;
            this.listings = updatedListings;
        }
    }

    async handleSave(event) {
        const listingId = event.target.dataset.listingId;
        const listing = this.listings.find(item => item.Id === listingId);
        
        if (!listing) {
            return;
        }

        const fields = {};
        fields[ID_FIELD.fieldApiName] = listingId;
        fields[OPTIN_FIELD.fieldApiName] = listing.Matchmaker_OptIn__c;
        const recordInput = { fields };

        try {
            const updatedRecord = await updateRecord(recordInput);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: `Settings for ${listing.Name} have been saved.`,
                    variant: 'success'
                })
            );
            
            await this.refreshData();

        } catch (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error Saving',
                    message: error.body.message,
                    variant: 'error'
                })
            );
        }
    }
}