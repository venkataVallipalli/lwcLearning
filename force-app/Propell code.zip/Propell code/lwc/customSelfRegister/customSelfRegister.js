import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import selfRegister from '@salesforce/apex/CustomLightningSelfRegController.selfRegister';

export default class CustomSelfRegister extends NavigationMixin(LightningElement) {
    @api accountId;
    @api regConfirmUrl;
    @api startUrl;
    @api widgetLabel = 'Create a New Account';
    @api firstnameLabel = 'First Name';
    @api lastnameLabel = 'Last Name';
    @api emailLabel = 'Email';
    @api suiteIdLabel = 'Suite Elite ID';
    @api passwordLabel = 'Create Password';
    @api confirmPasswordLabel = 'Confirm Password';
    @api submitButtonLabel = 'Sign Up';
    @api includePasswordField = false;
    @api extraFieldsFieldSet;
    @track showError = false;
    @track errorMessage = '';
    @track isLoading = false;

    handleSelfRegister() {
        // Validate all input fields
        const allValid = [...this.template.querySelectorAll('lightning-input')]
            .reduce((validSoFar, inputField) => {
                inputField.reportValidity(); // This will display the error message if the input is invalid
                return validSoFar && inputField.checkValidity();
            }, true);


        if (allValid) {
            // All inputs are valid, proceed with registration
            this.isLoading = true;

            // Collect input values for self registration
            const inputs = this.template.querySelectorAll('lightning-input');
            const fields = {};
            inputs.forEach(input => {
                fields[input.name] = input.value;
            });

            // Call the selfRegister Apex method
            selfRegister({
                firstname: fields.firstname,
                lastname: fields.lastname,
                email: fields.email,
                suiteId: fields.suiteEliteID,
                password: fields.password,
                confirmPassword: fields.confirmPassword,
                accountId: this.accountId,
                regConfirmUrl: this.regConfirmUrl,
                startUrl: decodeURIComponent(this.startUrl),
                includePassword: this.includePasswordField
            })
            .then(data => {
                console.log(JSON.stringify(data));
                if (data.message) {
                    this.errorMessage = data.message;
                    this.showError = true;
                }

                if (data.url) {
                    window.location.href = data.url;
                }
                this.isLoading = false;
            })
            .catch(error => {
                this.errorMessage = JSON.parse(JSON.stringify(error));
                this.showError = true;
                this.isLoading = false;
            });

        }
    }

    onKeyUp(event) {
        // Check for "Enter" key
        if (event.keyCode === 13) {
            this.handleSelfRegister();
        }
    }
}