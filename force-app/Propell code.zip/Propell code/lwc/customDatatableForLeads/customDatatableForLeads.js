import { LightningElement, track } from 'lwc';

export default class CustomDatatableForLeads extends LightningElement {

    @track
    omitPicklistValues = {
        'Status':
        [
            'Pardot Form',
            'Attempt #1',
            'Attempt #2',
            'Attempt #3',
            'Attempt #4',
            'Attempt #5',
            'Territory Not Available'
        ]
    };
}