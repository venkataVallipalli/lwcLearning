import { LightningElement, track, api, wire } from 'lwc';
import { FlowAttributeChangeEvent } from 'lightning/flowSupport';
import { publish, subscribe, unsubscribe, MessageContext, APPLICATION_SCOPE } from 'lightning/messageService';
import PROPERTY_CHANGE_CHANNEL from '@salesforce/messageChannel/propertyChangeChannel__c';
import Id from '@salesforce/user/Id';
import getPropertiesWithSelections from '@salesforce/apex/PropertySelectorController.getPropertiesWithSelections';
import saveSelectedProperties from '@salesforce/apex/PropertySelectorController.saveSelectedProperties';

const LOCAL_STORAGE_KEY = 'selectedProperties';

export default class PropertySelector extends LightningElement {
    @api hideOnDesktop;
    @track isMobileView = false;
    @track _properties = [];
    @track _propertyIds;
    @track _propertyIdString;
    @track userPropertySelection;
    userId = Id;
    lastPublishedMessage = null;
    subscription = null;

    get containerClass() {
        return this.hideOnDesktop ? 'desktop-hide' : '';
    }

    @api
    get propertyIdString() {
        return this._propertyIdString;
    }

    set propertyIdString(value) {
        this._propertyIdString = value;
    }
    
    @api
    get propertyIds() {
        return this._propertyIds;
    }

    set propertyIds(value) {
        this._propertyIds = value;
    }

    @api
    get properties() {
        return this._properties;
    }

    set properties(properties = []) {
        this._properties = [...properties];
    }

    get selectedProperties() {
        return this._properties.filter(property => property.selected);
    }

    get hasMultipleProperties() {
        return this._properties.length > 1;
    }

    get hasTenProperties() {
        return this._properties.length >= 10;
    }

    get comboboxOptions() {
        return this._properties.map(property => ({
            label: property.Name,
            value: property.Id,
            selected: property.selected
        }));
    }

    @wire(MessageContext)
    messageContext; 

    updateComboboxOptions() {
        const comboboxElement = this.template.querySelector('c-multi-select-combobox');
        if (comboboxElement) {
            comboboxElement.updateOptions(this.comboboxOptions);
        }
    }

    connectedCallback() {
        this.loadSelectedProperties();
        window.addEventListener('resize', this.resizeHandler);
        window.addEventListener('storage', this.handleStorageChange);
        this.subscribeToMessageChannel();
    }

    resizeHandler = this.debounce(() => {
        this.updateViewForScreenSize();
    }, 300);

    disconnectedCallback() {
        window.removeEventListener('resize', this.resizeHandler);
        window.removeEventListener('storage', this.handleStorageChange);
        this.unsubscribeFromMessageChannel();
    }

    renderedCallback() {
        this.updateViewForScreenSize();
    }

    updateViewForScreenSize() {
        const breakpointWidth = 768; 
        const isMobileSize = window.innerWidth < breakpointWidth;
        if (this.isMobileView !== isMobileSize) {
            this.isMobileView = isMobileSize;
        }
    }
    
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    async loadSelectedProperties() {
        try {
            const result = await getPropertiesWithSelections();
            const selectedProperties = result.selectionsJSON
                ? JSON.parse(result.selectionsJSON)
                : {};
            const propertiesResult = result.properties || [];

            if (propertiesResult.length > 10) {
                this.showAltDisplay = true;
            }

            this._properties = propertiesResult.map((property) => {
                const defaultColor = '#ff916d';
                return {
                    Id: property.Id,
                    Name: property.Name,
                    Property_Selector_Color__c: property.Property_Selector_Color__c,
                    Property_Selector_Abbreviation__c: property.Property_Selector_Abbreviation__c,
                    selected: !!selectedProperties[property.Id],
                    variant: selectedProperties[property.Id] ? 'brand' : 'neutral',
                    style: `background-color: ${property.Property_Selector_Color__c || defaultColor};`,
                    abbr: property.Property_Selector_Abbreviation__c || property.Name?.substring(0, 2)?.toUpperCase()
                };
            });

            // Keep localStorage in sync so customRecordList can hydrate IDs on warm loads.
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(selectedProperties));

            this.updateComboboxOptions();
            this.dispatchPropertyChangeEvent();
        } catch (error) {
            console.error('Error loading properties:', error);
        }
    }

    handlePropertyToggle(event) {
        const propertyId = event.currentTarget.dataset.id;
        const propertyIndex = this._properties.findIndex(property => property.Id === propertyId);
        if (propertyIndex !== -1) {
            this._properties[propertyIndex].selected = !this._properties[propertyIndex].selected;
            this._properties[propertyIndex].variant = this._properties[propertyIndex].selected ? 'brand' : 'neutral';

            this.saveSelectedProperties();
            this.dispatchPropertyChangeEvent();
            this.updateComboboxOptions();
        }
    }

    handleClearAllProperties() {
        this._properties = this._properties.map((property) => ({
            ...property,
            selected: false,
            variant: 'neutral'
        }));
        this.saveSelectedProperties();
        this.dispatchPropertyChangeEvent();
        this.updateComboboxOptions();
    }

    async saveSelectedProperties() {
        const selectedProperties = this._properties.reduce((acc, property) => {
            if (property.selected) {
                acc[property.Id] = true;
            }
            return acc;
        }, {});

        try {
            await saveSelectedProperties({
                userId: this.userId,
                selectionsJSON: JSON.stringify(selectedProperties)
            });

            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(selectedProperties));
        } catch(error) {
            console.error('Error saving selected properties:', error);
        }
    }

    dispatchPropertyChangeEvent() {
        let selectedPropertyIds = this._properties
            .filter(property => property.selected)
            .map(property => property.Id);

        if (selectedPropertyIds.length === 0) {
            selectedPropertyIds = this._properties.map(property => property.Id);
        }

        this.dispatchEvent(new CustomEvent('propertychange', {
            detail: { selectedPropertyIds },
            bubbles: true,
            composed: true 
        }));

        this._propertyIds = selectedPropertyIds;
        this._propertyIdString = selectedPropertyIds.map(id => `'${id}'`).join(',');
        const attributeChangeEvent = new FlowAttributeChangeEvent(
            'propertyIdString',
            JSON.stringify(selectedPropertyIds.map(id => String(id)))
        );
        this.dispatchEvent(attributeChangeEvent);

        this.publishPropertyChannelMessage();
    }
    
    handleComboboxChange(event) {
        const selectedValues = event.detail.map(option => option.value);

        this._properties = this._properties.map(property => ({
            Id: property.Id,
            Name: property.Name,
            Property_Selector_Color__c: property.Property_Selector_Color__c,
            Property_Selector_Abbreviation__c: property.Property_Selector_Abbreviation__c,
            selected: selectedValues.includes(property.Id),
            variant: selectedValues.includes(property.Id) ? 'brand' : 'neutral',
            style: property.style,
            abbr: property.abbr
        }));
        
        this.saveSelectedProperties();
        this.dispatchPropertyChangeEvent();
    }

    publishPropertyChannelMessage() {
        const selected = this.selectedProperties;
        const records = (selected.length ? selected : this._properties).map(property => ({
            Id: property.Id,
            Name: property.Name,
            style: property.style || '',
            abbr: property.abbr || '',
            selected: !!property.selected
        }));
        const recordIds = records.map(property => property.Id);
        const message = {
            records,
            message: this.propertyIdString,
            recordIds
        };
        this.lastPublishedMessage = this.propertyIdString;
        publish(this.messageContext, PROPERTY_CHANGE_CHANNEL, message);
    }

    subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext, 
                PROPERTY_CHANGE_CHANNEL, 
                (message) => this.handleMessage(message),
                { scope: APPLICATION_SCOPE }
            );
        }
    }

    unsubscribeFromMessageChannel() {
        if (this.subscription) {
            unsubscribe(this.subscription);
            this.subscription = null;
        }
    }

    handleStorageChange = (event) => {
        if (event.key === '1') {
            this.loadSelectedProperties();
            this.dispatchPropertyChangeEvent(); // Do not publish to avoid loop
        }
    }

    handleMessage(message) {
        // Only respond to subscriber handshake. Ignore our own publishes to avoid LMS loops.
        if (message.message === 'ready') {
            this.publishPropertyChannelMessage();
        }
    }
}