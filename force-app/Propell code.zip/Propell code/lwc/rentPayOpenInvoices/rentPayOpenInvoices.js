import { LightningElement, api, track, wire } from 'lwc';
import init from '@salesforce/apex/RENT_PayOpenInvoices.init';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import handleOpenInvoicePayment from '@salesforce/apex/RENT_PayOpenInvoices.handleOpenInvoicePayment';
import fetchNewPaymentMethodDetails from '@salesforce/apex/RENT_PayOpenInvoices.fetchNewPaymentMethodDetails';
import FORM_FACTOR from '@salesforce/client/formFactor';
import { publish, MessageContext } from 'lightning/messageService';
import PaymentMethodRefresh from '@salesforce/messageChannel/PaymentMethodRefresh__c';



import LightningConfirm from 'lightning/confirm';


export default class RENTpayOpenInvoices extends LightningElement {
    
    @api
    accountID;

    @api
    invoices;
    invoicesCopy;

    @api
    savedPaymentMethods;
    savedPaymentMethodsCopy;

    @api
    property;
    propertyCopy;

    @api
    isDebugging;

    @track
    isAddingPaymentMethod = false;

    @wire(MessageContext)
    messageContext;

    get isSmall() {
        return FORM_FACTOR === 'Small'; // Phone client
    }

    get isMedium() {
        return FORM_FACTOR === 'Medium'; // Tablet client
    }

    get isLarge() {
        return FORM_FACTOR === 'Large'; // Desktop client
    }
    
    get pmFlowInputVariables() {
      return [
        {
          name: "propertyId",
          type: "String",
          value: this.propertyCopy.Id
        },
        {
          name: "recordId",
          type: "String",
          value: this.accountID
        },
      ];
    }

    @track
    isInConfirmation = false;

    @track
    totalDue = 0;

    @track
    openInvoicesCount = 0;

    @track
    nextInvoiceIndex = 0;

    @track
    paymentMethodSelected;

    @track 
    amountToPay = 0;

    @track
    gridData = [];

    @track
    gridColumnsSmall = [
      {
        label: "Invoice Date",
        fieldName: "Invoice_Date__c",
        type: "date",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Invoice Type",
        fieldName: "Invoice_Type__c",
        type: "text",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Unpaid Balance",
        fieldName: "Unpaid_Balance__c",
        type: "currency",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Action",
        type: "button",

        hideDefaultActions: true,
        typeAttributes: {
            disabled: { fieldName: "payNowButtonDisabled" },
            name: "payButton", 
            label: { 
              fieldName: "buttonLabel" 
            }, 
            tooltip: "Pay Now Button", 
            variant: "brand", 
            context: { fieldName: "Id" },
            draftvaluesfieldname: "payNowButton",
            rowid: { fieldName: "Id" }
        }
      }
    ];

    @track
    gridColumnsLarge = [
      {
        label: "Invoice Date",
        fieldName: "Invoice_Date__c",
        type: "date",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Invoice Type",
        fieldName: "Invoice_Type__c",
        type: "text",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Total",
        fieldName: "Total_Amount__c",
        type: "currency",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Unpaid Balance",
        fieldName: "Unpaid_Balance__c",
        type: "currency",

        editable: false,
        hideDefaultActions: true
      },
      {
        label: "Action",
        type: "button",

        hideDefaultActions: true,
        typeAttributes: {
            disabled: { fieldName: "payNowButtonDisabled" },
            name: "payButton", 
            label: { 
              fieldName: "buttonLabel" 
            }, 
            tooltip: "Pay Now Button", 
            variant: "brand", 
            context: { fieldName: "Id" },
            draftvaluesfieldname: "payNowButton",
            rowid: { fieldName: "Id" }
        }
      }
    ];

    @track
    isLoading = false;

    get selectedPaymentMethodId(){
      return this.selectedPaymentMethod ? this.selectedPaymentMethod.Id : null;
    }

    connectedCallback() {
      this.init();
    }

    init(){
      init({
      }).then(results => {

        this.invoicesCopy = JSON.parse(JSON.stringify(this.invoices));
        this.propertyCopy = JSON.parse(JSON.stringify(this.property));

        if(this.savedPaymentMethods){
          this.savedPaymentMethodsCopy = JSON.parse(JSON.stringify(this.savedPaymentMethods));
        }else{
          this.savedPaymentMethodsCopy = [];
        }

        this.initFinished();
      }).catch(error =>{
        console.error('Error in init: ', error);
      });
    }

    initFinished(){
        this.generateGridData(this.invoicesCopy);
        this.generatePaymentMethodOptions();
    }

    generateGridData(invoices){
      this.totalDue = 0;
      let totalDueCents = 0;
      let gridData = [];
      this.openInvoicesCount = invoices.length;

      invoices.forEach((invoice, index) =>{

        if(index < this.nextInvoiceIndex){
          invoice.payNowButtonDisabled = true;
          invoice.buttonLabel = 'Paid!';
          this.openInvoicesCount--;
        }else if(index === this.nextInvoiceIndex){
          invoice.payNowButtonDisabled = false;
          invoice.buttonLabel = 'Pay Now';
        }else{
          invoice.payNowButtonDisabled = true;
          invoice.buttonLabel = '...';
        }
        
        gridData.push(invoice);

        let invoiceTotalDue = invoice.Unpaid_Balance__c ? invoice.Unpaid_Balance__c : 0;
        totalDueCents += Math.round(invoiceTotalDue * 100);
      });

      this.totalDue = totalDueCents / 100;
      this.gridData = gridData;
    }

    generatePaymentMethodOptions(){
      
        this.paymentMethodOptions = this.savedPaymentMethodsCopy.map(savedPaymentMethod => {
            return {
                label: savedPaymentMethod.Name,
                value: savedPaymentMethod.Id
            };
        });
        this.selectedPaymentMethod = this.savedPaymentMethodsCopy[0];
    }

    handleRowAction(event) {
      const actionName = event.detail.action.name; // Get the 'name' defined in typeAttributes
      const row = event.detail.row; // Get the full row data for the clicked row

      switch (actionName) {
          case 'payButton':
              let invoiceId = row.Id;
              this.payInvoice(invoiceId);
              break;
          default:
              break;
      }
    }

  async payInvoice(invoiceId){

    let invoice = this.invoicesCopy.find(inv => inv.Id === invoiceId);
    this.currentInvoice = invoice;
    let unpaidBalance = invoice.Unpaid_Balance__c;
    // let convenienceFee = this.generateConvFee(invoice);
    // let totalAmount = unpaidBalance + convenienceFee;

    this.amountToPay = unpaidBalance;

    this.howMuchWouldYouLikeToPay = "How much would you like to pay? Amount cannot exceed the invoice balance.";
    this.isInConfirmation = true;
  }

  generateConvFee(invoice, amountToPay){
    // let unpaidBalance = invoice.Unpaid_Balance__c;
    // let convFeePercent = invoice.Property__r.Convenience_Fee_Percent__c;
    // let convFeeMin = invoice.Property__r.Convenience_Fee_Minimum__c;
    // let convFeeMax = invoice.Property__r.Convenience_Fee_Maximum__c;

    this.propertyCopy.Rent_Payment_Convenience_Fee_P__c = !this.propertyCopy.Rent_Payment_Convenience_Fee_P__c ? 0 : this.propertyCopy.Rent_Payment_Convenience_Fee_P__c;
    this.propertyCopy.Rent_Payment_Convenience_Fee_F__c = !this.propertyCopy.Rent_Payment_Convenience_Fee_F__c ? 0 : this.propertyCopy.Rent_Payment_Convenience_Fee_F__c;

    // Convert to cents (integers) to avoid floating-point precision issues
    const amountToPayCents = Math.round(amountToPay * 100);
    const flatFeeCents = Math.round(this.propertyCopy.Rent_Payment_Convenience_Fee_F__c * 100);
    
    const percentageFeeCents = Math.round(
        (amountToPayCents * this.propertyCopy.Rent_Payment_Convenience_Fee_P__c) / 100
    );
    
    const totalFeeCents = percentageFeeCents + flatFeeCents;
    
    // Convert back to dollars - this will always have exactly 2 decimal places
    let result = totalFeeCents / 100;
    return result;
  }

  showToast(title, message, variant='info'){
    this.dispatchEvent(
        new ShowToastEvent({
            title,
            message,
            variant
        })
    );
  }

  handleConfirmCancelClick(){
    this.isInConfirmation = false;
  }

  handleConfirmClick(){

    var input = this.template.querySelector(".amountToPay");
    let amountToPay = input.value;
    
    if(amountToPay <= 0 || amountToPay > this.currentInvoice.Unpaid_Balance__c){
      this.showToast('Invalid Amount', 'Please enter a valid amount to pay.', 'error');
      return;
    }

    let convenienceFee = 0;
    if(this.selectedPaymentMethod.Payment_Method_Type__c === 'Credit Card'){
      convenienceFee = this.generateConvFee(this.currentInvoice, amountToPay);
    }
    
    this.handlePayment(this.currentInvoice, amountToPay, convenienceFee, this.selectedPaymentMethodId);
  }

  handlePayment(invoice, amountToPay, convenienceFee, selectedPaymentMethodId){

    this.isLoading = true;
    handleOpenInvoicePayment({
      openInvoiceId: invoice.Id,
      amountToPay: amountToPay,
      convFee: convenienceFee,
      paymentMethodId: selectedPaymentMethodId
    }).then(result => {

      if(result.status === 'error'){
        this.isLoading = false;
        this.showToast('Payment Failed', 'There was an error processing your payment, please reach out to your location manager.', 'error');
        return;
      }

      this.showToast('Payment Successful', 'Your payment was processed successfully.', 'success');

      invoice.Unpaid_Balance__c -= amountToPay;
      if(invoice.Unpaid_Balance__c == 0){
        ++this.nextInvoiceIndex;
      }
      
      this.generateGridData(this.invoicesCopy);

      this.isInConfirmation = false;
      this.isLoading = false;
    }).catch(error =>{
      console.error('Error in handlePayment: ', error);
      this.isLoading = false;
      this.showToast('Payment Failed', 'There was an error processing your payment, please reach out to your location manager', 'error');
    });
    
  }

  handlePaymentMethodChange(){
    var input = this.template.querySelector("lightning-radio-group");
    this.selectedPaymentMethod = this.savedPaymentMethodsCopy.find(pm => pm.Id === input.value);
  }

  handleAddPaymentMethodClick(){
    this.isAddingPaymentMethod = true;
  }

  handleFlowStatusChange(event) {
    if (event.detail.status === 'FINISHED') {
      const outputVariables = event.detail.outputVariables;
      
      outputVariables.forEach(outputVar => {

        if(outputVar.name === 'ShowError' && outputVar.value != null && outputVar.value != ''){
          this.showToast('Error adding payment method', outputVar.value, 'error');
        } else if(outputVar.name === "newPaymentMethodId" && outputVar.value != null && outputVar.value != ''){
          
          fetchNewPaymentMethodDetails({
            paymentMethodId: outputVar.value
          }).then(result => {

            this.isAddingPaymentMethod = false;

            this.savedPaymentMethodsCopy.unshift(result);
            this.generatePaymentMethodOptions();

            publish(this.messageContext, PaymentMethodRefresh, { refresh: true });

            this.showToast('Payment Method Added', 'The new payment method was added successfully.', 'success');
          }).catch(error =>{
            console.error('Error in fetchNewPaymentMethodDetails: ', error);
            this.showToast('Error', 'There was an error retrieving the new payment method details: ' + error.body.message, 'error');
          });
        

        }
        

      });

    }
  }

  handleAddPaymentMethodCancelClick(){
    this.isAddingPaymentMethod = false;
  }

}