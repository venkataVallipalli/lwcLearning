import { LightningElement, api, wire  } from 'lwc';
import { FlowAttributeChangeEvent } from 'lightning/flowSupport';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getWeeklyStatistics from '@salesforce/apex/SFWPropertySelectSubscriberController.getWeeklyStatistics';

export default class SFWPropertySelectSubscriber extends LightningElement {
    @api records;
    @api recordIds;
    @api invoicesLastWeek;
    @api invoicesNextWeek;
    @api selectedPropertyIds = [];
    @api selectedProperties;
    @api lastWeekCount;
    @api lastWeekTotalInvoice;
    @api lastWeekTotalDue;
    @api nextWeekCount;
    @api nextWeekTotalInvoice;
    @api propertyIds;


    @wire(getWeeklyStatistics, { propertyIds: '$selectedPropertyIds' })
    wiredRecords({ error, data }) {
        if (data) {
            this.lastWeekCount = data.lastWeekCount;
            this.lastWeekTotalInvoice = `$${data.lastWeekTotalInvoice.toFixed(2)}`;
            this.lastWeekTotalDue = `$${data.lastWeekTotalDue.toFixed(2)}`;
            this.nextWeekCount = data.nextWeekCount;
            this.nextWeekTotalInvoice = `$${data.nextWeekTotalInvoice.toFixed(2)}`;
            this.invoicesLastWeek = data.invoicesLastWeek;
            this.invoicesNextWeek = data.invoicesNextWeek;
            this.dispatchEvent(new FlowAttributeChangeEvent('lastWeekCount', this.lastWeekCount));
            this.dispatchEvent(new FlowAttributeChangeEvent('lastWeekTotalInvoice', this.lastWeekTotalInvoice));
            this.dispatchEvent(new FlowAttributeChangeEvent('lastWeekTotalDue', this.lastWeekTotalDue));
            this.dispatchEvent(new FlowAttributeChangeEvent('nextWeekCount', this.nextWeekCount));
            this.dispatchEvent(new FlowAttributeChangeEvent('nextWeekTotalInvoice', this.nextWeekTotalInvoice));
            this.dispatchEvent(new FlowAttributeChangeEvent('invoicesLastWeek', this.invoicesLastWeek));
            this.dispatchEvent(new FlowAttributeChangeEvent('invoicesNextWeek', this.invoicesNextWeek));
        } else if (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error fetching records',
                    message: error.body.message,
                    variant: 'error',
                }),
            );
        }
    }

    handlePropertyIdsChange(event) {
        this.selectedPropertyIds = event.detail.ids;
        this.selectedProperties = event.detail.properties;
    }
}