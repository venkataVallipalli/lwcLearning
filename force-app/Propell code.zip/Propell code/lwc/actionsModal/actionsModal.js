import { api } from 'lwc';
import LightningModal from 'lightning/modal';
import { NavigationMixin } from 'lightning/navigation';

export default class ActionsModal extends NavigationMixin(LightningModal) {
    @api sObjectName
    @api flowName;
    @api recordId;
    @api recordName;
    @api recordStatus;
    @api inputVariables = [];
    @api phoneNumber;
    @api actionType;

    get headerLabel() {
        if (this.actionType === 'phone') {
            return 'Call Options';
        }
        return `${this.recordName}`;
    }

    get flowApiName() {
        switch (this.flowName) {
            case 'Opportunity':
                return 'SFW_Opportunity_Actions';
            case 'MRA':
                return 'SFW_Make_Rental_Agreement';
            case 'Make Payment':
                return 'RENT_Create_Payment_Transaction';
            case 'Collection Center':
                return 'RENT_Collection_Center';    
            case 'New Note':
                return 'SFW_New_Note';
            case 'Convert Lead':
                return 'Convert_Member_Lead';              
            default:
                return '';
        }
    }

    get showConvertButton() {
        return this.sObjectName === 'Lead' && this.recordStatus !== 'Converted';
    }


    get actionItems() {
        if (this.actionType === 'phone') {
            return [
                { 
                    label: `Call ${this.formatPhoneNumber(this.phoneNumber)}`, 
                    icon: 'utility:call',
                    href: `tel:${this.phoneNumber}`
                },
                { 
                    label: 'RingCentral', 
                    //action: this.handleRingCentralCall.bind(this), 
                    icon: 'utility:call',
                    href: `https://app.ringcentral.com/r/call?number=${this.phoneNumber}`
                }
            ];
        }

        switch (this.sObjectName) {
            case 'Account':
                return [
                    { label: 'Opportunities', action: this.navigateToMemberOpportunities.bind(this) },
                    { label: 'Payments', action: this.navigateToMemberPayments.bind(this) },
                    { label: 'Directory Listings', action: this.navigateToDirectoryListings.bind(this) },
                    { label: 'New Note', action: this.navigateToNewNote.bind(this) },
                    { label: 'New Task', action: this.navigateToNewTask.bind(this) },
                    { label: 'Edit', action: this.navigateToEdit.bind(this) }
                ];
            case 'Lead':
                return [
                    { label: 'New Note', action: this.navigateToNewNote.bind(this) },
                    { label: 'New Task', action: this.navigateToNewTask.bind(this) },
                    { label: 'Edit', action: this.navigateToEdit.bind(this) }
                ];
            case 'Opportunity':
                return [
                    { label: 'Edit', action: this.navigateToEdit.bind(this) },
                    { label: '🪄 Wizard Actions', action: this.navigateToWizardActions.bind(this) }
                ];
            default:
                return [];
        }
    }

    handleClose() {
        this.close();
    }

    navigateToMemberOpportunities() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Account',
                relationshipApiName: 'Opportunities',
                actionName: 'view'
            }
        })
        this.close();
    }

    navigateToMemberPayments() {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                // url: `/account/${this.recordId}/?tabset-ea7b1=2` Flowpay sandbox url
                url: `/account/${this.recordId}/?tabset-57db1=2` // Production url
            }
        });
        this.close();
    }

    navigateToDirectoryListings() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Account',
                relationshipApiName: 'Directory_Listings__r',
                actionName: 'view'
            }
        })
        this.close();
    }


    navigateToConvert() {
        this.flowName = 'Convert Lead';
        this.inputVariables = [
            {
                name: 'recordId',
                type: 'String',
                value: this.recordId
            }
        ];
    }

    navigateToNewNote() {
        this.flowName = 'New Note';
        this.inputVariables = [
            {
                name: 'recordId',
                type: 'String',
                value: this.recordId
            }
        ];
    }

    handleStatusChange(event) {
        if (event.detail.status === 'FINISHED') {
            this.close();
        }
    }
    

    navigateToNewTask() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Task',
                actionName: 'new'
            },
            state: {
                defaultFieldValues: `WhoId=${this.recordId}`,
                nooverride: '1',
                navigationLocation: 'RELATED_LIST'
            }
        });
    }

    navigateToEdit() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: this.sObjectName,
                actionName: 'edit'
            },
        });
    }

    navigateToWizardActions() {
        this.flowName = 'Opportunity';
        this.inputVariables = [
            { name: 'recordId', type: 'String', value: this.recordId }
        ];
    }

    formatPhoneNumber(phoneNumber) {
        const cleaned = ('' + phoneNumber).replace(/\D/g, '');
        
        const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        
        if (match) {
            return `(${match[1]}) ${match[2]}-${match[3]}`;
        }
        
        return phoneNumber;
    }
}