import { LightningElement, wire, track, api } from 'lwc';
import { getListInfoByName, getListRecordsByName, getListInfosByObjectName } from "lightning/uiListsApi";

export default class CustomListView extends LightningElement {
    @api sObjectName;
    @api selectedPropertyIds = [];
    @track listViewLabel;
    @track error;
    @track columns = [];
    @track records;
    @track sortedBy;
    @track sortedDirection = 'asc';
    @track searchKey = '';
    @track filteredRecords = [];
    @track selectedListView = '';
    @track listViewOptions = [];
    @track selectedIds = [];

    wiredListInfoData;
    fieldsToQuery;

    get isLead() {
        return this.sObjectName === 'Lead';
    }

    get isAccount() {
        return this.sObjectName === 'Account';
    }

    connectedCallback() {
        if (this.isLead) {
            this.selectedListView = 'Active_Member_Leads';
        }
        if (this.isAccount) {
            this.selectedListView = 'Members';
        }
    }

    @wire(getListInfosByObjectName, {
        objectApiName: '$sObjectName',
        pageSize: 20,
    })
    listOfLists({ error, data }) {
        if (data) {
            this.listViewOptions = data.lists.map(list => ({
                label: list.label,
                value: list.apiName
            }));
            console.log(JSON.stringify(this.listViewOptions));
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.lists = undefined;
        }
    }

    @wire(getListInfoByName, {
        objectApiName: '$sObjectName',
        listViewApiName: "$selectedListView",
    })
    listInfo(result) {
        this.wiredListInfoData = result;
        if (result.data) {
            this.error = undefined;
            this.columns = this.mapColumns(result.data.displayColumns);
            this.listViewLabel = result.data.label;
            this.fieldsToQuery = result.data.displayColumns.map(column => `${this.sObjectName}.${column.fieldApiName}`);
            if (this.isAccount && !this.fieldsToQuery.includes('Account.Most_Recent_Opportunity_Property__c')) {
                this.fieldsToQuery.push('Account.Most_Recent_Opportunity_Property__c');
            }

            console.log('columns: ', JSON.stringify(result.data.displayColumns));
            console.log('this.columns: ', JSON.stringify(this.columns));
            console.log('Fields to query: ', JSON.stringify(this.fieldsToQuery)); 
        } else if (result.error) {
            this.error = result.error;
            this.columns = undefined;
        }
    }

    @wire(getListRecordsByName, {
        objectApiName: '$sObjectName',
        listViewApiName: "$selectedListView",
        fields: '$fieldsToQuery', 
        // sortBy: ["Lead.Name"],
        // where: '$generateWhereClauseString'
    })
    listRecords({ error, data }) {
        if (data) {
            console.log('data: ', JSON.stringify(data.records));
            this.records = this.flattenRecords(data.records);
            this.error = undefined;
            // console.log('flattenedrecords: ', JSON.stringify(this.records));
            this.filterRecords();
        } else if (error) {
            console.log('Record fetch error: ' + JSON.stringify(error));
            this.error = error;
        }
    }

    mapColumns(displayColumns) {
        // Sample record data for identifying column types
        const sampleRecord = this.records && this.records.length > 0 ? this.records[0] : null;
    
        return displayColumns.map(col => {
            const isEmailField = col.fieldApiName.includes('Email');
            const isPhoneField = col.fieldApiName.includes('Phone');
            const isPropertyField = col.fieldApiName.includes('Property');
            // const isBooleanField = col.fieldApiName.startsWith('Is');
            
            // Default type
            let type = 'text';
    
            if (col.fieldApiName === 'Name') {
                return {
                    label: col.label,
                    fieldName: 'nameUrl',
                    type: 'url',
                    typeAttributes: {
                        label: { fieldName: 'Name' }
                    },
                    sortable: col.sortable
                };
            }
            
            if (isPropertyField) {
                return {
                    label: col.label,
                    fieldName: 'propertyUrl',
                    type: 'url',
                    typeAttributes: {
                        label: { fieldName: col.fieldApiName }
                    },
                    sortable: col.sortable
                };
            }
    
            if (isEmailField) {
                type = 'email';
            } else if (isPhoneField) {
                type = 'phone';
            }
    
            return {
                label: col.label,
                fieldName: col.fieldApiName,
                type,
                sortable: col.sortable
            };
        });
    }

    handleListViewChange(event) {
        this.selectedListView = event.detail.value;
    }

    handlePropertyIdsChange(event) {
        this.selectedPropertyIds = event.detail.ids;
        this.selectedProperties = event.detail.properties;
        console.log('prop ids change: ', JSON.stringify(this.selectedPropertyIds));
        this.filterRecords();
        console.log('filteredRecords: ', JSON.stringify(this.filteredRecords));
    }

    handleSort(event) {
        this.sortedBy = event.detail.fieldName;
        this.sortedDirection = event.detail.sortDirection;
        this.sortData(this.sortedBy, this.sortedDirection);
    }

    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.filteredRecords));
        let keyValue = (a) => {
            return a[fieldname];
        };
        let isReverse = direction === 'asc' ? 1 : -1;
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : '';
            y = keyValue(y) ? keyValue(y) : '';
            return isReverse * ((x > y) - (y > x));
        });
        this.filteredRecords = parseData;
    }
    
    flattenRecords(records) {
        return records.map(record => {
            const flattened = { id: record.id, nameUrl: `/s/${this.sObjectName.toLowerCase()}/${record.id}` };
    
            Object.keys(record.fields).forEach(fieldName => {
                const fieldData = record.fields[fieldName];
                
                if (typeof fieldData.value === 'object' && fieldData.value !== null && 'fields' in fieldData.value) {
                    // Handle nested records, e.g. Property__r
                    const relatedRecord = fieldData.value;
                    Object.keys(relatedRecord.fields).forEach(nestedFieldName => {
                        const nestedFieldData = relatedRecord.fields[nestedFieldName];
                        const nestedApiFieldName = `${fieldName}.${nestedFieldName}`;
                        flattened[nestedApiFieldName] = nestedFieldData.displayValue || nestedFieldData.value;
                    });

                    if (relatedRecord.apiName === 'Property__c') {
                        flattened['Property__c'] = relatedRecord.id;
                        flattened['propertyUrl'] = `/s/property/${relatedRecord.id}`
                    }
                    // if (fieldName === 'Property__r') {
                    //     flattened['Property__c'] = relatedRecord.id;
                    //     flattened['propertyUrl'] = `/s/property/${relatedRecord.id}`
                    // }
                } else {
                    // Handle non-nested fields
                    flattened[fieldName] = fieldData.displayValue || fieldData.value;
                }
            });
    
            return flattened;
        });
    }

    handleSearch(event) {
        this.searchKey = event.target.value.toLowerCase();
        this.filterRecords();
    }

    filterRecords() {
        let records = this.records;
        if (this.searchKey) {
            records = this.filterBySearchKey(records, this.searchKey);
        }
    
        if (Array.isArray(this.selectedPropertyIds) && this.selectedPropertyIds.length > 0) {
            records = this.filterByProperty(records, this.selectedPropertyIds);
        }
    
        this.filteredRecords = records;
    }
    
    filterBySearchKey(records, searchKey) {
        const lowerCaseSearchKey = searchKey.toLowerCase();
        return records.filter(record =>
            Object.keys(record).some(key =>
                String(record[key]).toLowerCase().includes(lowerCaseSearchKey)
            )
        );
    }
    
    filterByProperty(records, propertyIds) {
        if (!Array.isArray(propertyIds) || propertyIds.length === 0) return records;
        if (records) {
            return records.filter(record => propertyIds.includes(record.Property__c));
        }
    }

    handleRowSelection(event) {
        this.selectedIds = event.detail.selectedRows.map(row => row.id);
        console.log(JSON.stringify(this.selectedIds));
    }
}