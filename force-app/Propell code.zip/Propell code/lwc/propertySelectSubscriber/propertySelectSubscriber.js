import { LightningElement, wire, api } from 'lwc';
import { publish, subscribe, MessageContext, APPLICATION_SCOPE } from 'lightning/messageService';
import PROPERTY_CHANGE_CHANNEL from '@salesforce/messageChannel/propertyChangeChannel__c';
import { FlowAttributeChangeEvent } from 'lightning/flowSupport';

export default class SubscribeMessage extends LightningElement {
    @wire(MessageContext)
    messageContext;

    subscription = null;

    @api
    message = '';
    @api 
    properties;
    @api 
    propertyIds;

    connectedCallback() {
        this.subscribeToMessageChannel();
    }

    subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext, 
                PROPERTY_CHANGE_CHANNEL, 
                (message) => this.handleMessage(message),
                { scope: APPLICATION_SCOPE }
            );
            this.publishReadyMessage();
        }
    }

    publishReadyMessage() {
        const message = {
            message: 'ready',
            records: this.properties || [],
            recordIds: this.propertyIds || [] 
        };
        publish(this.messageContext, PROPERTY_CHANGE_CHANNEL, message);
    }

    handleMessage(message) {
        if (message.message !== 'ready') {
            this.message = message.message;
            this.properties = message.records;
            this.propertyIds = message.recordIds;
            this.dispatchEvent(new FlowAttributeChangeEvent('message', this.message));
            this.dispatchEvent(new FlowAttributeChangeEvent('properties', this.properties));
            this.dispatchEvent(new FlowAttributeChangeEvent('propertyIds', this.propertyIds));
    
            const propertyIdsChangeEvent = new CustomEvent('propertyidschange', {
                detail: { ids: this.propertyIds, properties: this.properties }
            });
            this.dispatchEvent(propertyIdsChangeEvent);
        }
    }
}