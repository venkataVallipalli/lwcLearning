import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from "lightning/navigation";
import getRecords from '@salesforce/apex/CustomRecordListController.getRecords';
import ActionsModal from 'c/actionsModal';
import ListActionsModal from 'c/listActionsModal';

// Must match propertySelector LOCAL_STORAGE_KEY so warm loads can query before LMS.
const LOCAL_STORAGE_KEY = 'selectedProperties';

export default class CustomRecordList extends NavigationMixin(LightningElement) {
    @api sObjectName;
    @api hideOnDesktop;
    @api selectedPropertyIds = [];
    @api selectedProperties = [];

    @track records = [];
    @track searchKey = '';
    @track filteredRecords = [];
    @track listViewOptions = [];
    @track selectedListView = '';
    @track sortField = '';
    @track sortOrder = '';

    recordTypeIds = {
        'Lead': '0121I000000UxHkQAK',
        'Opportunity': '0121I000000UxHzQAK',
        'Account': '0121I000000Ux7iQAC'
    };

    // Flexipage tab body targets for Mogli SMS conversation view.
    // Capture each object's target from App Simulator (state.target) when wiring Account/Opportunity.
    smsTabTargets = {
        Lead: 'flexipage_tab7__body',
        // Account: 'flexipage_tabX__body',
        // Opportunity: 'flexipage_tabY__body'
    };

    get containerClass() {
        return this.hideOnDesktop ? 'desktop-hide' : '';
    }

    get isLead() {
        return this.sObjectName === 'Lead';
    }

    get isOpportunity() {
        return this.sObjectName === 'Opportunity';
    }

    get isAccount() {
        return this.sObjectName === 'Account';
    }

    get isExpiringOpportunity() {
        return this.selectedListView === 'Opportunities Expiring 60 Days';
    }

    // Keep a valid @wire config while preventing large unfiltered queries.
    get wiredPropertyIds() {
        return this.selectedPropertyIds?.length ? this.selectedPropertyIds : undefined;
    }

    connectedCallback() {
        if (this.isLead) {
            this.sortField = 'Date_Submitted__c';
            this.sortOrder = 'desc';
        } else {
            this.sortField = 'Name';
            this.sortOrder = 'asc';
        }
        this.hydratePropertyIdsFromCache();
        this.updateListViewOptions();
    }

    hydratePropertyIdsFromCache() {
        try {
            const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (!raw) {
                return;
            }
            const selectedMap = JSON.parse(raw);
            if (!selectedMap || typeof selectedMap !== 'object') {
                return;
            }
            const ids = Object.keys(selectedMap)
                .filter((id) => selectedMap[id])
                .map((id) => String(id));
            if (ids.length) {
                this.selectedPropertyIds = ids;
            }
        } catch (error) {
            // Ignore corrupt cache; LMS will supply IDs.
        }
    }

    propertyIdsChanged(nextIds) {
        const current = this.selectedPropertyIds || [];
        if (current.length !== nextIds.length) {
            return true;
        }
        const currentSet = new Set(current);
        return nextIds.some((id) => !currentSet.has(id));
    }

    updateListViewOptions() {
        if (this.isLead) {
            this.listViewOptions = [
                { label: 'Active Member Leads', value: 'Active_Member_Leads' },
                { label: 'Member Leads on Waitlist', value: 'Member_Leads_on_Waitlist' },
                { label: 'Member Leads Kept on List', value: 'Member_Leads_Kept_on_List' },
                { label: 'All Member Leads', value: 'All_Member_Leads' }
            ];
        } else if (this.isAccount) {
            this.listViewOptions = [
                { label: 'Active Members', value: 'Members' },
                { label: 'New Active Members Last 30 Days', value: 'New Active Members Last 30 Days' },
                { label: 'Pending Members', value: 'Pending Members' },
                { label: 'Prospect Members', value: 'Prospect Members' },
                { label: 'Former Members', value: 'Former Members' },
                { label: 'All Members', value: 'AllAccounts' }
            ];
        } else if (this.isOpportunity) {
            this.listViewOptions = [
                { label: 'Active Opportunities', value: 'Active Opportunities' },
                { label: 'Future Term Unsigned', value: 'Future Term Unsigned' },
                { label: 'Opportunities Expiring 60 Days', value: 'Opportunities Expiring 60 Days' },
                { label: 'All Opportunities', value: 'All Opportunities' }
            ];
        }

        // Set default list view if not selected
        if (this.listViewOptions.length > 0) {
            this.selectedListView = this.listViewOptions[0].value;
        }
    }


    @wire(getRecords, { sObjectName: '$sObjectName', propertyIds: '$wiredPropertyIds', listViewName: '$selectedListView' })
    wiredRecords({ error, data }) {
        if (!this.selectedPropertyIds?.length) {
            return;
        }

        if (data) {
            this.records = data.map(record => {
                if (this.isAccount) {
                    return this.processAccountRecord(record);
                }
                if (this.isLead) {
                    return this.processLeadRecord(record);
                }
                if (this.isOpportunity) {
                    return this.processOpportunityRecord(record);
                }
                return null;
            }).filter(Boolean);
            this.filterRecords();
            this.sortRecords();
        } else if (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error fetching records',
                    message: error.body?.message || 'Unknown error',
                    variant: 'error',
                }),
            );
        }
    }

    processLeadRecord(record) {
        const property = this.selectedProperties?.find(prop => prop.Id === record.Property__c);
        const phone = record.MobilePhone || record.Phone || '';
        return {
            Id: record.Id,
            Name: record.Name,
            Status: record.Status,
            Rating: record.Rating,
            Date_Submitted__c: record.Date_Submitted__c,
            Property__c: record.Property__c,
            phone,
            hrefPhone: phone ? `tel:${phone}` : '',
            propertyStyle: property?.style || '',
            propertyAbbr: property?.abbr || ''
        };
    }

    processOpportunityRecord(record) {
        const property = this.selectedProperties?.find(prop => prop.Id === record.Property__c);
        const phone = record.Account?.PersonMobilePhone || record.Account?.Phone || '';
        const propertyName = record.Property__r?.Name || '';
        return {
            Id: record.Id,
            Name: record.Name,
            Property__c: record.Property__c,
            Property__r: { Name: propertyName },
            propertyName,
            Rental_Agreement_Status__c: record.Rental_Agreement_Status__c,
            Agreement_End_Date__c: record.Agreement_End_Date__c,
            phone,
            hrefPhone: phone ? `tel:${phone}` : '',
            propertyStyle: property?.style || '',
            propertyAbbr: property?.abbr || ''
        };
    }

    processAccountRecord(record) {
        const suitesMap = new Map();

        if (record.Opportunities) {
            record.Opportunities.forEach(opportunity => {
                const property = opportunity.Property__r;
                if (!property?.Id) {
                    return;
                }

                const suiteName = opportunity.Suite__r?.Name ? `Suite ${opportunity.Suite__r.Name}` : '';
                const suiteKey = suiteName ? `${property.Id}-${suiteName}` : `${property.Id}`;
                if (!suitesMap.has(suiteKey)) {
                    suitesMap.set(suiteKey, {
                        key: suiteKey,
                        propertyId: property.Id,
                        propertyStyle: this.selectedProperties?.find(prop => prop.Id === property.Id)?.style || '',
                        propertyAbbr: this.selectedProperties?.find(prop => prop.Id === property.Id)?.abbr || '',
                        suiteName
                    });
                }
            });
        }

        const phone = record.PersonMobilePhone || record.Phone || '';
        return {
            Id: record.Id,
            Name: record.Name,
            isSuiteEliteInactive: !(record.IsCustomerPortal ?? record.isCustomerPortal),
            phone,
            hrefPhone: phone ? `tel:${phone}` : '',
            suites: Array.from(suitesMap.values())
        };
    }

    handleListViewChange(event) {
        this.selectedListView = event.detail.value;
    }
    
    // Handle the propertyIds change event (LMS). Prefer cache for initial wire; update if IDs differ.
    handlePropertyIdsChange(event) {
        const ids = (event.detail.ids || []).map((id) => String(id));
        const properties = event.detail.properties || [];
        // Keep only plain fields so LMS/Apex proxies never enter @api/@track state.
        this.selectedProperties = properties.map((prop) => ({
            Id: prop.Id,
            Name: prop.Name,
            style: prop.style || '',
            abbr: prop.abbr || ''
        }));
        if (this.propertyIdsChanged(ids)) {
            this.selectedPropertyIds = ids;
        } else if (this.records?.length) {
            // IDs already hydrated from cache; refresh badge metadata without re-querying.
            this.records = this.records.map((record) => {
                if (this.isAccount) {
                    return {
                        ...record,
                        suites: (record.suites || []).map((suite) => {
                            const property = this.selectedProperties.find(
                                (prop) => prop.Id === suite.propertyId
                            );
                            return {
                                ...suite,
                                propertyStyle: property?.style || '',
                                propertyAbbr: property?.abbr || ''
                            };
                        })
                    };
                }
                const property = this.selectedProperties.find(
                    (prop) => prop.Id === record.Property__c
                );
                return {
                    ...record,
                    propertyStyle: property?.style || '',
                    propertyAbbr: property?.abbr || ''
                };
            });
            this.filterRecords();
            this.sortRecords();
        }
        if (!ids.length) {
            this.records = [];
            this.filteredRecords = [];
        }
    }

    handleSearch(event) {
        this.searchKey = event.target.value.toLowerCase();
        this.filterRecords();
    }

    filterRecords() {
        const source = Array.isArray(this.records) ? this.records : [];
        if (this.searchKey) {
            this.filteredRecords = source.filter(record => {
                if (!record || typeof record !== 'object') {
                    return false;
                }
                const haystack = [
                    record.Name,
                    record.Status,
                    record.Rating,
                    record.phone,
                    record.Rental_Agreement_Status__c,
                    record.propertyName,
                    ...(record.suites || []).map(suite => suite.suiteName)
                ].filter(Boolean).join(' ').toLowerCase();
                return haystack.includes(this.searchKey);
            });
        } else {
            this.filteredRecords = [...source];
        }
    }

    sortRecords() {
        if (!this.sortField || !Array.isArray(this.filteredRecords)) {
            return;
        }
        const field = this.sortField;
        const ascending = this.sortOrder === 'asc';
        this.filteredRecords = [...this.filteredRecords].sort((a, b) => {
            const fieldA = a?.[field] != null ? String(a[field]).toLowerCase() : '';
            const fieldB = b?.[field] != null ? String(b[field]).toLowerCase() : '';
            if (fieldA < fieldB) {
                return ascending ? -1 : 1;
            }
            if (fieldA > fieldB) {
                return ascending ? 1 : -1;
            }
            return 0;
        });
    }

    async handleListActionsClick(event) {
        const actionType = event.target.dataset.action;

        const result = await ListActionsModal.open({
            size: 'full',
            actionType: actionType,
            sObjectName: this.sObjectName,
            currentSortField: this.sortField,
            currentSortOrder: this.sortOrder
        });

        if (result && result.field && result.order) {
            this.sortField = result.field;
            this.sortOrder = result.order;
            this.sortRecords();
        }
    }

    async handleActionsClick(event) {
        const recordId = event.target.dataset.id;
        const recordName = event.target.dataset.name;
        const recordStatus = event.target.dataset.status;
        const flowName = event.target.dataset.flow;

        await ActionsModal.open({
            size: 'full',
            flowName: flowName,
            recordId: recordId,
            recordName: recordName,
            recordStatus: recordStatus,
            sObjectName: this.sObjectName
        });
    }

    handleRecordNav(event) {
        const recordId = event.currentTarget.dataset.id;
        if (!recordId) {
            return;
        }
        this[NavigationMixin.Navigate]({
            type: "standard__recordPage",
            attributes: {
              recordId: recordId,
              objectApiName: this.sObjectName,
              actionName: "view",
            },
        });
    }

    handleHelptextClick(event) {
        event.stopPropagation();
    }

    handleSmsNav(event) {
        event.preventDefault();
        const recordId = event.currentTarget.dataset.id;
        const phone = event.currentTarget.dataset.phone;
        const tabTarget = this.smsTabTargets[this.sObjectName];

        if (tabTarget) {
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                    recordId,
                    objectApiName: this.sObjectName,
                    actionName: 'view'
                },
                state: {
                    target: tabTarget
                }
            });
            return;
        }

        // Fallback until Account/Opportunity tab targets are configured.
        if (phone) {
            window.location.href = `sms:${phone}`;
        }
    }

    handleCreateNew() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: this.sObjectName,
                actionName: 'new'
            },
            state: {
              recordTypeId: this.recordTypeIds[this.sObjectName]
            }
        });
    }

    handleOppAction(event) {
        const recordId = event.target.dataset.id;

        this[NavigationMixin.Navigate]({
            type: "standard__quickAction",
            attributes: {
                apiName: 'Opportunity.Wizard_Actions'
            },
            state: {
                objectApiName: 'Opportunity',
                context: "RECORD_DETAIL",
                recordId: recordId,
                backgroundContext: "/lightning/r/Opportunity/" + recordId + "/view"
            }
        });
    }

    handlePhoneClick(event) {
        event.preventDefault();
        const phone = event.currentTarget.dataset.phone;
        if (!phone) {
            return;
        }
    
        const sanitizedPhone = phone.replace(/[^0-9+]/g, '');
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: `aircall://call?to=${sanitizedPhone}`
            }
        });
    }
}