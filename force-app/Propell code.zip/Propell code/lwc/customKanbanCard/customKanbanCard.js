import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import ActionsModal from 'c/actionsModal';

export default class CustomKanbanCard extends NavigationMixin(LightningElement) {
    @api sObjectName;
    @api record;

    get statusField() {
        return this.sObjectName === 'Lead' ? 'Status' : 'StageName';
    }

    @track
    recordHref;

    @track
    propertyHref;

    async connectedCallback() {
        
        this.recordHref = await this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.record.Id,
                actionName: 'view',
            },
        });

        this.propertyHref = await this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.record.Property__c,
                actionName: 'view',
            },
        });
    }

    handleDragStart(event) {
        // Set the drag data with the record ID
        event.dataTransfer.setData('text/plain', this.record.Id);
        // Dispatch the custom event with the record ID
        this.dispatchEvent(new CustomEvent('itemdrag', {
            detail: this.record.Id
        }));
    }

    // Navigate to the record detail page when the name is clicked 
    navigateToRecordDetail(event) {
        event.preventDefault();
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.record.Id,
                objectApiName: this.sObjectName, 
                actionName: 'view',
            },
        });
    }

    navigateToRelatedRecord(event) {
        event.preventDefault();
        const recordId = event.currentTarget.dataset.recordId;
        const objectName = event.currentTarget.dataset.objectName;
        
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                objectApiName: objectName,
                actionName: 'view'
            }
        });
    }
    

    async handleActionsClick(event) {
        const result = await ActionsModal.open({
            size: 'small',
            recordId: this.record.Id,
            recordName: this.record.Name,
            recordStatus: this.record[this.statusField],
            sObjectName: this.sObjectName
        });
    }
}