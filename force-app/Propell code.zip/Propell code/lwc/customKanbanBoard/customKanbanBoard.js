import { LightningElement, track, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import updateRecordStatus from '@salesforce/apex/CustomKanbanController.updateRecordStatus';

const leadStatuses = [
    'New', 
    'No Response', 
    'Contacted', 
    'Tour Pending', 
    'Tour Complete', 
    'No Show', 
    'Keep on List', 
    'Waitlist', 
    'Closed'
];

const opportunityStatuses = [
    'Tour Complete', 
    'Application', 
    'Reservations', 
    'Pending Signature', 
    'Lease Signed', 
    'Member Orientation', 
    'Waitlist'
];

export default class CustomKanbanBoard extends LightningElement {
    @api sObjectName;
    @track _searchTerm = '';
    @track _records = [];
    @track recordId;
    @api selectedPropertyIds = [];
    filteredRecords = [];
    isWorking = false;

    // @track
    // _sortedBy;
    // @track
    // _sortDirection;
    // @track
    // _isCaseInsensitiveSort;
    // @track
    // _gridColumns;

    // @api
    // get sortedBy() {
    //     return this._sortedBy;
    // }
    // set sortedBy(value) {
    //     this._sortedBy = value;
    // }

    // @api
    // get sortDirection() {
    //     return this._sortDirection;
    // }
    // set sortDirection(value) {
    //     this._sortDirection = value;
    //     this.filterRecords();
    // }

    // @api 
    // get isCaseInsensitiveSort() {
    //     return this._isCaseInsensitiveSort;
    // }
    // set isCaseInsensitiveSort(value) {
    //     this._isCaseInsensitiveSort = value;
    //     this.filterRecords();
    // }

    // @api
    // get gridColumns () {
    //     return this._gridColumns;
    // }
    // set gridColumns(value) {
    //     this._gridColumns = value;
    //     this.filterRecords();
    // }

    get allowedStatuses() {
        return this.sObjectName === 'Lead' ? leadStatuses : opportunityStatuses;
    }

    get statusField() {
        return this.sObjectName === 'Lead' ? 'Status' : 'StageName';
    }

    @api
    get records() {
        return this._records;
    }
    set records(value) {
        this._records = value;

        // transform records to add lookup field values for sorting and display purposes
        this._records = this._records.map(record => {
            const transformedRecord = { ...record };
            for (const key in record) {
                let index = key.indexOf('__r_');
                if (record[key] && index > -1) { // 84.65, 72752194

                    let key1 = key.substring(0,index+3);

                    if(!transformedRecord[key1]){
                        transformedRecord[key1] = {};
                    }

                    let subkey = key.substring(index+4);
                    let capitalizedSubkey = subkey.charAt(0).toUpperCase() + subkey.slice(1);

                    transformedRecord[key1][capitalizedSubkey] = record[key];
                }
            }
            return transformedRecord;
        });


        this.filterRecords();
    }

    @api
    get searchTerm() {
        return this._searchTerm;
    }
    set searchTerm(value) {
        this._searchTerm = value;
        this.filterRecords();
    }

    filterRecords() {
        //console.log('filterRecords', JSON.stringify(this._records)); 
        if (!this._searchTerm) {
            this.filteredRecords = this._records;
        } else {
            const searchTerm = this._searchTerm.toLowerCase();
            this.filteredRecords = this._records.filter(record => {
                // Add any fields you want to search through

                const searchableFields = Object.keys(record).map(key => record[key]).filter(Boolean); // Remove null/undefined values

                // const searchableFields = [
                //     record.Name,
                //     record[this.statusField],
                //     this.sObjectName === 'Lead' ? record.Specialty__c : null,
                //     this.sObjectName === 'Lead' ? record.Specialty__c : null,
                //     this.sObjectName === 'Lead' ? record.Email : record.Account?.Name,
                //     this.sObjectName === 'Lead' ? record.Company : null,
                //     record.Property__r?.Name,
                // ].filter(Boolean); // Remove null/undefined values
    
                return searchableFields.some(field => 
                    String(field).toLowerCase().includes(searchTerm)
                );
            });
        }

        // if(this.sortedBy && this.sortDirection && this.gridColumns ) {
        //     this.doSort(this.sortedBy, this.sortDirection);
        // }
        
        // Update status counts after filtering
        this.computedStatusObjects();
    }


    // doSort(sortField, sortDirection) {

    //     // Determine if column type will allow field values to be converted to lower case
    //     let isString = false;
    //     if (this.isCaseInsensitiveSort) {
    //         const colType = this.gridColumns.find(c => c.fieldName == sortField).type;
    //         switch (colType) {
    //             case 'phone':
    //             case 'text':
    //             case 'email':
    //             case 'url':
    //             case 'richtext':
    //             case 'combobox':
    //                 isString = true;
    //                 break;
    //             default:
    //         }
    //     }
        
    //     // Change sort field from Id to Name for lookups
    //     if (sortField.endsWith('_lookup')) {
    //         sortField = sortField.slice(0,sortField.lastIndexOf('_lookup')) + '';
    //     }       
    //     let fieldValue = row => row[sortField] || '';
    //     let reverse = sortDirection === 'asc'? 1: -1;
            
    //     if (this.isCaseInsensitiveSort && isString) {
    //         this.filteredRecords = [...this.filteredRecords.sort(
    //             (a,b)=>(a=fieldValue(a).toLowerCase(),b=fieldValue(b).toLowerCase(),reverse*((a>b)-(b>a)))
    //         )];
    //     } else {
    //         let sortF2 = function(a,b){
    //                 a = a[sortField] || '';
    //                 b = b[sortField] || '';

    //                 return reverse * ((a>b)-(b>a));
    //         }
    //         let tempFilteredRecords = JSON.parse(JSON.stringify(this.filteredRecords)).sort(sortF2);
    //         this.filteredRecords = tempFilteredRecords;
    //     }
        
    // }

    get statusObjects() {
        return this.computedStatusObjects();
    }

    computedStatusObjects() {
        const statusCounts = {};
        const statusField = this.statusField;

        this.filteredRecords.forEach(record => {
            let status = record[statusField];
            if (!statusCounts[status]) {
                statusCounts[status] = 0;
            }
            statusCounts[status]++;
        });

        return this.allowedStatuses.map(status => ({
            status,
            noRecords: statusCounts[status] || 0
        }));
    }

    get calcWidth() {
        let len = this.statusObjects.length - 1;
        return `width: calc(100vw / ${len})`;
    }

    handlePropertyIdsChange(event) {
        this.selectedPropertyIds = event.detail.ids;
    }

    handleListItemDrag(event) {
        this.recordId = event.detail;
    }

    handleItemDrop(event) {
        const newStatus = event.detail.newStatus;
        const record = this._records.find(record => record.Id === this.recordId);
        const statusField = this.statusField;
        
        if (record && record[statusField] !== newStatus) {
            // Update client-side first
            this.isWorking = true;
            const recordIndex = this._records.findIndex(record => record.Id === this.recordId);
            const updatedRecords = [...this._records];
            updatedRecords[recordIndex] = { 
                ...record, 
                [statusField]: newStatus
            };
            this._records = updatedRecords;

            // Then update server-side
            this.updateHandler(this.recordId, newStatus) 
                .then(() => {
                    this.dispatchEvent(new CustomEvent('statuschange', {
                        detail: { 
                            recordId: this.recordId, 
                            newStatus: newStatus,
                            statusField: statusField
                        }
                    }));
                    this.filterRecords();
                })
                .catch(() => {
                    const revertedRecords = [...this._records];
                    revertedRecords[recordIndex] = { ...record };
                    this._records = revertedRecords;
                    this.filterRecords();
                })
                .finally(() => {
                    this.isWorking = false;
                });  

        } else {
            console.log('Status unchanged. No update necessary.');
        }
    }

    async updateHandler(recordId, newStatus) {
        try {
            await updateRecordStatus({ recordId: recordId, newStatus: newStatus });
            const statusLabel = this.sObjectName === 'Lead' ? 'status' : 'stage';
            this.showToast('Success', `${this.sObjectName} ${statusLabel} updated successfully`, 'success');
        } catch (error) {
            this.showToast('Error', `Failed to update ${this.sObjectName} status.`, 'error');
            console.error('updateRecordStatus error:', JSON.stringify(error));
            throw error;
        }
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            })
        );
    }
}