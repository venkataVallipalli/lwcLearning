import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getUsers from '@salesforce/apex/UMP_UserDirectoryController.getUsers';

const ALPHABET = [
    ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
    'All'
];

export default class ump_userDirectory extends NavigationMixin(LightningElement) {
    @api limitSize = 20;

    searchTerm = '';
    letterFilter = '';
    offsetSize = 0;

    users = [];
    totalRecords = 0;
    error;
    isLoading = true;

    _showPhotos = true;
    _searchTimeout;
    _wiredResult;

    @api
    get showPhotos() {
        return this._showPhotos;
    }
    set showPhotos(value) {
        this._showPhotos = value === true || value === 'true';
    }

    get alphabet() {
        return ALPHABET.map((letter) => ({
            label: letter,
            key: letter,
            cssClass:
                (letter === 'All' && !this.letterFilter) ||
                letter === this.letterFilter
                    ? 'alphabet-link alphabet-link_selected'
                    : 'alphabet-link'
        }));
    }

    get currentPage() {
        const size = this.normalizedLimitSize;
        if (size <= 0 || this.totalRecords === 0) {
            return 1;
        }
        return Math.floor(this.offsetSize / size) + 1;
    }

    get totalPages() {
        const size = this.normalizedLimitSize;
        if (size <= 0 || this.totalRecords === 0) {
            return 1;
        }
        return Math.ceil(this.totalRecords / size);
    }

    get normalizedLimitSize() {
        const size = Number(this.limitSize);
        return !size || size <= 0 ? 20 : size;
    }

    get disablePrevious() {
        return this.offsetSize === 0;
    }

    get disableNext() {
        return this.offsetSize + this.normalizedLimitSize >= this.totalRecords;
    }

    get hasUsers() {
        return this.users && this.users.length > 0;
    }

    get showEmptyState() {
        return !this.isLoading && !this.error && !this.hasUsers;
    }

    get pageLabel() {
        return `Page ${this.currentPage} of ${this.totalPages}`;
    }

    get displayUsers() {
        return (this.users || []).map((user) => {
            const cityState = [user.City, user.State].filter(Boolean).join(', ');
            return {
                ...user,
                cityState,
                hasTitle: Boolean(user.Title),
                hasCityState: Boolean(cityState),
                hasEmail: Boolean(user.Email),
                hasPhone: Boolean(user.Phone),
                hasOpenLocations: Boolean(user.Open_Locations__c)
            };
        });
    }

    @wire(getUsers, {
        searchTerm: '$searchTerm',
        letterFilter: '$letterFilter',
        limitSize: '$limitSize',
        offsetSize: '$offsetSize'
    })
    wiredUsers(result) {
        this._wiredResult = result;
        const { data, error } = result;
        if (data) {
            this.users = data.users || [];
            this.totalRecords = data.totalRecordCount || 0;
            this.error = undefined;
            this.isLoading = false;
        } else if (error) {
            this.users = [];
            this.totalRecords = 0;
            this.error = error;
            this.isLoading = false;
        }
    }

    handleSearch(event) {
        const value = event.target.value || '';
        window.clearTimeout(this._searchTimeout);
        this._searchTimeout = window.setTimeout(() => {
            this.searchTerm = value;
            this.offsetSize = 0;
        }, 300);
    }

    handleLetterFilter(event) {
        const letter = event.currentTarget.dataset.letter;
        this.letterFilter = letter === 'All' ? '' : letter;
        this.searchTerm = '';
        this.offsetSize = 0;

        const searchInput = this.template.querySelector('[data-id="search-input"]');
        if (searchInput) {
            searchInput.value = '';
        }
    }

    handlePrevious() {
        if (this.disablePrevious) {
            return;
        }
        this.offsetSize = Math.max(0, this.offsetSize - this.normalizedLimitSize);
    }

    handleNext() {
        if (this.disableNext) {
            return;
        }
        this.offsetSize = this.offsetSize + this.normalizedLimitSize;
    }

    handleUserClick(event) {
        event.preventDefault();
        const recordId = event.currentTarget.dataset.id;
        if (!recordId) {
            return;
        }
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId,
                objectApiName: 'User',
                actionName: 'view'
            }
        });
    }
}