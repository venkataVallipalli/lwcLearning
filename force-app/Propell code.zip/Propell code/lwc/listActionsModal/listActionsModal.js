import { api, track } from 'lwc';
import LightningModal from 'lightning/modal';
import { NavigationMixin } from 'lightning/navigation';

export default class ListActionsModal extends NavigationMixin(LightningModal) {
    @api actionType;
    @api sObjectName;
    @api currentSortField;
    @api currentSortOrder;

    @track nameSortOrder = '';
    @track statusSortOrder = '';
    @track ratingSortOrder = '';
    @track dateSubmittedSortOrder = '';

    get isLead() {
        return this.sObjectName === 'Lead';
    }

    connectedCallback() {
        this.initializeSortOrder();
    }

    initializeSortOrder() {
        if (this.currentSortField) {
            switch (this.currentSortField) {
                case 'Name':
                    this.nameSortOrder = this.currentSortOrder === 'asc' ? 'Ascending ↑' : 'Descending ↓';
                    break;
                case 'Status':
                    this.statusSortOrder = this.currentSortOrder === 'asc' ? 'Ascending ↑' : 'Descending ↓';
                    break;
                case 'Rating':
                    this.ratingSortOrder = this.currentSortOrder === 'asc' ? 'Ascending ↑' : 'Descending ↓';
                    break;
                case 'Date_Submitted__c':
                    this.dateSubmittedSortOrder = this.currentSortOrder === 'asc' ? 'Ascending ↑' : 'Descending ↓';
                    break;
                default:
                    break;
            }
        }
    }

    get modalTitle() {
        switch (this.actionType) {
            case 'filter':
                return `Filter`;
            case 'sort':
                return `Sort`;
            case 'new':
                return `Create New ${this.sObjectName}`;
            default:
                return 'Action';
        }
    }

    get isFilter() {
        return this.actionType === 'filter';
    }

    get isSort() {
        return this.actionType === 'sort';
    }

    get isNameSort() {
        return this.nameSortOrder !== '';
    }

    get isStatusSort() {
        return this.statusSortOrder !== '';
    }

    get isRatingSort() {
        return this.ratingSortOrder !== '';
    }

    get isDateSubmittedSort() {
        return this.dateSubmittedSortOrder !== '';
    }

    handleClose() {
        this.close();
    }

    handleAction() {
        // Pass the sort selection back to the customRecordList component
        let sortField = '';
        let sortOrder = '';
        
        if (this.isDateSubmittedSort) {
            sortField = 'Date_Submitted__c';
            sortOrder = this.dateSubmittedSortOrder.includes('Ascending') ? 'asc' : 'desc';
        } else if (this.isNameSort) {
            sortField = 'Name';
            sortOrder = this.nameSortOrder.includes('Ascending') ? 'asc' : 'desc';
        } else if (this.isStatusSort) {
            sortField = 'Status';
            sortOrder = this.statusSortOrder.includes('Ascending') ? 'asc' : 'desc';
        } else if (this.isRatingSort) {
            sortField = 'Rating';
            sortOrder = this.ratingSortOrder.includes('Ascending') ? 'asc' : 'desc';
        }
        
        const sortSelection = {
            field: sortField,
            order: sortOrder
        };
        
        this.close(sortSelection);
    }

    handleSortClick(event) {
        const field = event.currentTarget.dataset.field;
        if (field === 'Date_Submitted__c') {
            this.toggleSortOrder('dateSubmittedSortOrder');
            this.nameSortOrder = '';
            this.statusSortOrder = '';
            this.ratingSortOrder = '';
        } else if (field === 'Name') {
            this.toggleSortOrder('nameSortOrder');
            this.dateSubmittedSortOrder = '';
            this.statusSortOrder = '';
            this.ratingSortOrder = '';
        } else if (field === 'Status') {
            this.toggleSortOrder('statusSortOrder');
            this.nameSortOrder = '';
            this.dateSubmittedSortOrder = '';
            this.ratingSortOrder = '';
        } else if (field === 'Rating') {
            this.toggleSortOrder('ratingSortOrder');
            this.nameSortOrder = '';
            this.statusSortOrder = '';
            this.dateSubmittedSortOrder = '';
        }
    }

    toggleSortOrder(sortOrderField) {
        if (this[sortOrderField] === '') {
            this[sortOrderField] = 'Ascending ↑';
        } else if (this[sortOrderField] === 'Ascending ↑') {
            this[sortOrderField] = 'Descending ↓';
        } else {
            this[sortOrderField] = 'Ascending ↑';
        }
    }
}