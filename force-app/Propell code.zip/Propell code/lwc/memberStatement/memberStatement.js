/* memberStatement.js
 Description:
  LWC: memberStatement

  Dev date range: circa 250415
  Developer: SOLVD

  Revision History:
    circa 250415: Version 1
      * Original
    260210: Version 2
      * MAP added the Unpaid Invoice Balance data to the LWC
*/

import { LightningElement, track, api, wire } from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import jsPDF from '@salesforce/resourceUrl/jspdf';
import autoTable from '@salesforce/resourceUrl/jspdf_autotable';
import Logo_MSS from '@salesforce/resourceUrl/Logo_MSS';
import getInvoicePropertiesForMember from '@salesforce/apex/MemberStatementController.getInvoicePropertiesForMember';
import getInvoicesForLastYear from '@salesforce/apex/MemberStatementController.getInvoicesForLastYear';
import getInvoicesForThisYear from '@salesforce/apex/MemberStatementController.getInvoicesForThisYear';
import getInvoicesForLastMonth from '@salesforce/apex/MemberStatementController.getInvoicesForLastMonth';
import getInvoicesForThisMonth from '@salesforce/apex/MemberStatementController.getInvoicesForThisMonth';
import getFilteredMemberInvoicesWithLineItems from '@salesforce/apex/MemberStatementController.getFilteredMemberInvoicesWithLineItems';
import sendPdfAsEmailAttachment from '@salesforce/apex/MemberStatementController.sendPdfAsEmailAttachment';

export default class MemberStatement extends LightningElement {
    @api recordId;
    jsPDFInitialized = false;
    @track isMobileView = false;
    @track invoices = [];
    @track filteredInvoices = [];
    @track invoicesLoaded = false;
    @track startingBalance = 0;
    @track endingBalance = 0;
    @track memberUnpaidInvBal = 0;
    @track memberName = '';
    @track propertyName = '';
    @track isLoading = false;
    @track properties = [];
    @track selectedPropertyId = '';
    @track showPropertySelection = false;

    @track timePeriod = 'thisMonth'; // Default to this month
    @track customStartDate;
    @track customEndDate;

    get timePeriodOptions() {
        return [
            { label: 'Last Year', value: 'lastYear' },
            { label: 'This Year', value: 'thisYear' },
            { label: 'Last Month', value: 'lastMonth' },
            { label: 'This Month', value: 'thisMonth' },
            { label: 'Custom Date', value: 'custom' }
        ];
    }
    
    get isCustomTimePeriod() {
        return this.timePeriod === 'custom';
    }

    get noInvoices() {
        return this.invoicesLoaded && this.filteredInvoices.length === 0;
    }

    get hasMultipleProperties() {
        return this.properties.length > 1;
    }

    get propertyOptions() {
        return this.properties.map(property => ({ label: property.Name, value: property.Id }));
    }

    @track displaySecurityDepositHistory = true; // This property is used to control the visibility of the 'c-security-deposit-history' LWC.

    connectedCallback() {
        getInvoicePropertiesForMember({ memberId: this.recordId })
            .then((data) => {
                this.properties = data;
                this.showPropertySelection = data.length > 1;
                if (data.length === 1) {
                    this.selectedPropertyId = data[0].Id;
                    this.displaySecurityDepositHistory = data[0].NewSecurityDepositFeatures__c;
                    this.fetchFilteredInvoices();
                } 
            })
            .catch((error) => {
                console.error('Error fetching properties: ', error);
            })
    }

    renderedCallback() {
        this.updateViewForScreenSize();

        if (this.jsPDFInitialized) {
            return;
        }
        this.jsPDFInitialized = true;
        
        loadScript(this, jsPDF)
        .then(() => {
            loadScript(this, autoTable)
            .then(() => {
            })
            .catch(error => {
                console.error('autoTable error');
            })
        })
        .catch(error => {
            console.error('error');
            throw(error);
        });
    }

    updateViewForScreenSize() {
        const breakpointWidth = 640; 
        const isMobileSize = window.innerWidth < breakpointWidth;
        if (this.isMobileView !== isMobileSize) {
            this.isMobileView = isMobileSize;
        }
    }

    /* ================================================
      Data Processing and Filtering
    ================================================ */
    fetchFilteredInvoices() {
        this.isLoading = true;

        let params = {
            memberId: this.recordId,
            propertyId: this.selectedPropertyId
        };
        switch (this.timePeriod) {
            case 'lastYear':
                getInvoicesForLastYear(params)
                    .then(data => this.processInvoicesData(data))
                    .catch(error => console.error('Error:', error));
                break;
            case 'thisYear':
                getInvoicesForThisYear(params)
                    .then(data => this.processInvoicesData(data))
                    .catch(error => console.error('Error:', error));
                break;
            case 'lastMonth':
                getInvoicesForLastMonth(params)
                    .then(data => this.processInvoicesData(data))
                    .catch(error => console.error('Error:', error));
                break;
            case 'thisMonth':
                getInvoicesForThisMonth(params)
                    .then(data => this.processInvoicesData(data))
                    .catch(error => console.error('Error:', error));
                break;
            case 'custom':
                if (this.customStartDate && this.customEndDate) {
                    getFilteredMemberInvoicesWithLineItems({
                        memberId: this.recordId,
                        propertyId: this.selectedPropertyId,
                        startDate: this.customStartDate,
                        endDate: this.customEndDate
                    })
                    .then(data => this.processInvoicesData(data))
                    .catch(error => console.error('Error:', error));
                } else {
                    this.isLoading = false;
                }
                break;
            default:
                this.isLoading = false;
                console.error('Invalid time period');
        }
    }

    handlePropertySelect(event) {
        this.selectedPropertyId = event.target.value;
        this.fetchFilteredInvoices();
        this.showPropertySelection = false;
    }

    handleTimePeriodChange(event) {
        this.timePeriod = event.detail.value;
        this.fetchFilteredInvoices();
    }

    handleCustomStartDateChange(event) {
        this.customStartDate = event.detail.value;
        if (this.customEndDate) {
            this.fetchFilteredInvoices();
        }
    }

    handleCustomEndDateChange(event) {
        this.customEndDate = event.detail.value;
        this.fetchFilteredInvoices();
    }

     // This function processes the invoices data to format the dates
    processInvoicesData(data) {
        if (!data || !data.invoices) {
            this.filteredInvoices = [];
            return;
        }

        const processedInvoices = data.invoices.map(invoice => {
            const processedRelatedPayments = Array.isArray(invoice.relatedPayments) ? invoice.relatedPayments.map(payment => {
                let descriptionStr = payment.paymentMethod ? `${payment.paymentMethod}` : '';
                if (payment.referenceId) {
                    descriptionStr += ` - Reference: ${payment.referenceId}`;
                }
                return {
                    ...payment,
                    paymentDate: this.formatDate(payment.paymentDate),
                    paymentDescription: descriptionStr
                };
            }) : [];
    
            return {
                ...invoice,
                expanded: false,
                iconName: invoice.expanded ? 'utility:chevrondown' : 'utility:chevronright',
                invoiceDate: this.formatDate(invoice.invoiceDate), 
                relatedPayments: processedRelatedPayments
            };
        });
        
        this.filteredInvoices = processedInvoices;
        this.invoices = processedInvoices;
        this.startingBalance = data.startingBalance;
        this.endingBalance = data.endingBalance;
        this.memberUnpaidInvBal = data.memberUnpaidInvBal;
        this.memberName = data.memberName;
        this.propertyName = data.propertyName;
        this.invoicesLoaded = true;
        this.isLoading = false;
    }

    toggleLineItems(event) {
        const invoiceId = event.currentTarget.dataset.id;
        this.filteredInvoices = this.filteredInvoices.map(invoice => {
            if (invoice.Id === invoiceId) {
                const isExpanded = !invoice.expanded;
                return {
                    ...invoice,
                    expanded: !invoice.expanded,
                    iconName: isExpanded ? 'utility:chevrondown' : 'utility:chevronright'
                };
            }
            return invoice;
        });
    }

    expandAll() {
        this.isLoading = true;

        this.filteredInvoices = this.invoices.map(invoice => ({ 
            ...invoice,
            expanded: true,
            iconName: 'utility:chevrondown'
        }));
        
        setTimeout(() => {
            this.isLoading = false;
        }, 0);
    }

    collapseAll() {
        this.isLoading = true;

        this.filteredInvoices = this.invoices.map(invoice => ({
            ...invoice, 
            expanded: false,
            iconName: 'utility:chevronright' 
        }));
        
        setTimeout(() => {
            this.isLoading = false;
        }, 0);
    }

  /* ==================================================
    PDF METHODS
  ================================================== */
    generatePdf(action){
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Set the title and member's name
        doc.addImage(Logo_MSS, 'PNG', 13, 10, 35, 15);
        doc.setFontSize(11);
        doc.setTextColor(100);

        doc.text(`${this.memberName}`, 14, 32);
        doc.text(`${this.propertyName}`, 14, 40);

        const dateRange = this.getDateRange(this.filteredInvoices);
        doc.text(`Statement for ${dateRange}`, 14, 48);

        /* 260212MAP: Commented out for the page update to Unpaid Invoice Balance value only
        const pageWidth = doc.internal.pageSize.getWidth();
        const startingBalanceStr = `Starting Balance: ${this.formatCurrency(this.startingBalance)}`;
        const startingBalanceX = pageWidth - doc.getTextWidth(startingBalanceStr) - 14;
        doc.text(startingBalanceStr, startingBalanceX, 32);

        const endingBalanceStr = `Ending Balance: ${this.formatCurrency(this.endingBalance)}`;
        doc.text(endingBalanceStr, startingBalanceX, 40);
        */

        //260210MAP: Added for the Member Statement update to only display the Unpaided Invoice Balance
        const memberUnpaidInvBalStr = `Unpaid Invoice Balance: ${this.formatCurrency(this.memberUnpaidInvBal)}`;
        doc.text(memberUnpaidInvBalStr, 14, 56);
        //doc.text(memberUnpaidInvBalStr, 125, 40);

        const headers = [
            ['Date', 'Description', 'Amount', 'Balance']
        ];

        try {
            const body = [];
            this.filteredInvoices.forEach((invoice) => {
                if (invoice.isOrphanedPayment) {
                    // For orphaned payments, only add the payment rows
                    if (invoice.relatedPayments) {
                        invoice.relatedPayments.forEach((payment) => {
                            body.push([
                                { content: payment.paymentDate, styles: { fillColor: [245, 245, 245] } },
                                { content: `Payment for Invoice #${invoice.invoiceNumber} - ${payment.paymentDescription}`, styles: { fillColor: [245, 245, 245] } },
                                { content: `-${this.formatCurrency(payment.amountToApply)}`, styles: { fillColor: [245, 245, 245], halign: 'right' } },
                                { content: this.formatCurrency(payment.runningBalance), styles: { fillColor: [245, 245, 245], halign: 'right' } }
                            ]);
                        });
                    }
                } else {
                    // Regular invoice processing
                    body.push([
                        invoice.invoiceDate,
                        `#${invoice.invoiceNumber} - Suite ${invoice.suite}`,
                        { content: this.formatCurrency(invoice.totalAmount), styles: { halign: 'right' } },
                        { content: this.formatCurrency(invoice.runningBalance), styles: { halign: 'right' } }
                    ]);
            
                    if (invoice.lineItems) {
                        invoice.lineItems.forEach((lineItem) => {
                            body.push([
                                '',
                                `   ${lineItem.Description__c}`,
                                { content: this.formatCurrency(lineItem.Amount__c, true), styles: { halign: 'right' } },
                                ''
                            ]);
                        });
                    }
            
                    if (invoice.relatedPayments) {
                        invoice.relatedPayments.forEach((payment) => {
                            const paymentStatus = payment.paymentStatus ? payment.paymentStatus : '';
                            body.push([
                                { content: payment.paymentDate, styles: { fillColor: [245, 245, 245] } },
                                { content: payment.paymentDescription, styles: { fillColor: [245, 245, 245] } },
                                { content: `-${this.formatCurrency(payment.amountToApply)}`, styles: { fillColor: [245, 245, 245], halign: 'right' } },
                                { content: this.formatCurrency(payment.runningBalance), styles: { fillColor: [245, 245, 245], halign: 'right' } }
                            ]);
                        });
                    }
                }
            });

            doc.autoTable({ 
                head: headers, 
                body: body,
                startY: 62,
                //startY: 56,
                styles: { fillColor: [255, 255, 255] },
                headStyles: {
                    fillColor: '#000000'
                },
                columnStyles: {
                    2: { halign: 'right' },
                    3: { halign: 'right' }  
                },
                alternateRowStyles: { fillColor: [255, 255, 255] }
            })

            

            const fileName = `${this.memberName.replace(/\s+/g, '')}${dateRange.replace(/[\s,]+/g, '')}InvoiceStatement.pdf`;
            if (action === 'download') {
                doc.save(fileName); 
            } else if (action === 'email') {
                // Convert the PDF to a base64 string and send it in an email
                const pdfBase64String = doc.output('datauristring').split(',')[1];
                this.sendPdfByEmail(pdfBase64String, fileName);
            }
        } catch (e) {
            console.error('Error generating PDF body:', e);
        } 
    }

    handleDownloadPdf() {
        this.generatePdf('download');
    }
    
    handleEmailPdf() {
        this.generatePdf('email');
    }
    
    sendPdfByEmail(pdfBase64String, fileName) {
        sendPdfAsEmailAttachment({ memberId: this.recordId, base64Pdf: pdfBase64String, pdfFileName: fileName})
            .then(result => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: `A PDF has been emailed to ${result}`,
                        variant: 'success'
                    })
                );
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: `There was an error sending the email.`,
                        variant: 'error'
                    })
                );
                console.error('Error sending email:', error);
            });
    }

    formatCurrency(amount, isLineItem) {
        const isNegative = amount < 0;
        const formattedAmount = isLineItem ? `${Math.abs(amount).toFixed(2)}` : `$${Math.abs(amount).toFixed(2)}`;
        return isNegative ? `-${formattedAmount}` : formattedAmount;
    }

    formatDate(dateString) {
        if (!dateString) return '';

        const dateParts = dateString.split('-'); 
        if (dateParts.length === 3) {
            const [year, month, day] = dateParts;
            return `${month}/${day}/${year}`; 
        }
        return dateString; 
    }

    getDateRange(invoices) {
        if (invoices.length === 0) {
            return '';
        }
        if(this.timePeriod === 'custom') {
            if (this.customStartDate && this.customEndDate) {
                return `${this.formatDate(this.customStartDate)} - ${this.formatDate(this.customEndDate)}`;
            }
        }

        const startDateStr = this.formatDate(invoices[0].invoiceDate);
        const endDateStr = this.formatDate(invoices[invoices.length - 1].invoiceDate);
        return `${startDateStr} - ${endDateStr}`;
    }
}