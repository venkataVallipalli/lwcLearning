import { LightningElement, api, wire, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getLargeFiles from '@salesforce/apex/GoogleDriveService.getLargeFiles';
import deleteAndArchiveFile from '@salesforce/apex/GoogleDriveService.deleteAndArchiveFile';

const columns = [
    { label: 'Service Ticket Id', fieldName: 'LinkedEntityId' },
    { label: 'File Id', fieldName: 'Id' },
    { label: 'File Name', fieldName: 'Title' },
    { label: 'Type', fieldName: 'FileExtension' },
    { label: 'Size (MB)', fieldName: 'formattedSize' },
    { 
        label: 'Download', 
        type: 'button', 
        typeAttributes: { 
            label: 'Download', 
            name: 'download', 
            variant: 'brand', 
            disabled: { fieldName: 'isDownloaded' } 
        } 
    },
    { 
        label: 'Delete', 
        type: 'button', 
        typeAttributes: { 
            label: 'Delete', 
            name: 'delete', 
            variant: 'destructive', 
            disabled: { fieldName: 'isDeleted' } 
        } ,
        cellAttributes: {
            iconName: { fieldName: 'deleteStatusIcon' },
            iconAlternativeText: 'Delete Status',
            iconPosition: 'right'
        }
    }
];

export default class ServiceTicketFileCleanup extends LightningElement {
    @track contentVersions;
    @track deletedCount = 0;
    @track totalCount = 0;
    error;
    columns = columns;

    @wire(getLargeFiles)
    wiredFiles({ error, data }) {
        if (data) {
            this.contentVersions = data.map(record => {
                return {
                    ...record,
                    downloadUrl: record.VersionDataUrl,
                    isDownloaded: false,
                    isDeleted: true,
                    deleteStatusIcon: '',
                    formattedSize: this.formatSize(record.ContentSize)
                };
            });
            this.totalCount = data.length;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.contentVersions = undefined;
        }
    }

    formatSize(bytes) {
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        if (actionName === 'download') {
            this.downloadFile(row.downloadUrl);
            this.markAsDownloaded(row.Id);
        } else if (actionName === 'delete') {
            this.deleteFile(row.ContentDocumentId, row.LinkedEntityId, row.Id);
        }
    }

    downloadFile(url) {
        const link = document.createElement('a');
        link.href = url;
        link.target = '_self';
        link.click();
    }

    markAsDownloaded(rowId) {
        this.contentVersions = this.contentVersions.map(record => {
            if (record.Id === rowId) {
                return { ...record, isDownloaded: true, isDeleted: false };
            }
            return record;
        });
    }

    deleteFile(contentDocumentId, LinkedEntityId, rowId) {
        this.contentVersions = this.contentVersions.map(record => {
            if (record.Id === rowId) {
                return { ...record, isDeleted: true, deleteStatusIcon: 'utility:spinner' };
            }
            return record;
        });

        deleteAndArchiveFile({ contentDocumentId: contentDocumentId, caseId: LinkedEntityId })
            .then((result) => {
                if (result === 'Success') {
                    this.contentVersions = this.contentVersions.map(record => {
                        if (record.Id === rowId) {
                            this.deletedCount += 1;
                            return { ...record, deleteStatusIcon: 'standard:task2' };
                        }
                        return record;
                    });
        
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'File deleted and case updated successfully.',
                            variant: 'success'
                        })
                    );
                }
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: 'An error occurred while deleting the file and updating the service ticket.',
                        variant: 'error'
                    })
                );
                console.error('Error deleting file and updating Service Ticket:', error);
            });
    }
}