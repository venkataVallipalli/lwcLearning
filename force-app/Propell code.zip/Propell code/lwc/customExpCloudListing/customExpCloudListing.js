import { LightningElement, api, track } from 'lwc';
import getCollectionItems from '@salesforce/apex/CustomExpCloudListingController.getCollectionItems';
import { NavigationMixin } from "lightning/navigation";

export default class CustomExpCloudListing extends NavigationMixin(LightningElement) {

    @api
    category;

    @track
    pages;

    isMobilePublisher = false;

    connectedCallback(){

        this.checkMobilePublisher();

        getCollectionItems({
            category: this.category
        }).then(results => {
            results = results.map(r => {
                if(r.Button_1_Link__c && r.Button_1_Link__c.indexOf('tel:') > -1){
                    r.isButton1LinkTel = true;
                }
                if(r.Button_2_Link__c && r.Button_2_Link__c.indexOf('tel:') > -1){
                    r.isButton2LinkTel = true;
                }
                return r;
            });

            this.pages = results;
        }).catch(err => console.log(err));
    }

    checkMobilePublisher(){
        // Check if running in a Mobile Publisher context
        if (this.$Browser && (this.$Browser.isPhone || this.$Browser.isTablet)) {
            // Potentially running in Mobile Publisher, but not definitive
            this.isMobilePublisher = true;
        }
        // Alternatively, parse the user agent for more specific checks
        const userAgent = navigator.userAgent;
        if (userAgent.includes('Salesforce Mobile')) {
             // More definitive check for Mobile Publisher
            this.isMobilePublisher = true;
        }
    }

    handleButtonClick(evt){
        let url = evt.target.dataset.url;

        if(url.indexOf("mailto:") > -1){
            window.location.href = url;
        }else if(url.indexOf("tel:") > -1){
            window.open(url);
        }else if(url.indexOf("internal:") > -1){
            let pageName = url.split(":")[1];
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                    attributes: {
                        pageName: pageName
                    }
            });
        }else{
            if(this.isMobilePublisher){
                this[NavigationMixin.Navigate]({
                        type: "standard__webPage",
                        attributes: {
                            url: url
                        }
                }, false);
            }else{
                this[NavigationMixin.GenerateUrl]({
                        type: 'standard__webPage',
                        attributes: {
                            url
                        }
                    }).then(url => {
                        window.open(url, "_self");
                    });
            }
        }
    }

    handleMoreClick(evt){
        let index = evt.target.dataset.index;
        let page = this.pages[index];
        page.isShowingMoreInformation = !page.isShowingMoreInformation;
    }

}