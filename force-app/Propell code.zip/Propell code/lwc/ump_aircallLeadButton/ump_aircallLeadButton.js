import { LightningElement, api, wire, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

// Dynamically handle Phone field regardless of whether it's an Account, Contact, or Lead
import PHONE_FIELD from '@salesforce/schema/Lead.Phone';
import NAME_FIELD from '@salesforce/schema/Lead.Name';

export default class ump_aircallLeadButton extends NavigationMixin(LightningElement) {
    @api recordId; // Automatically injected by the Quick Action framework
    @api objectApiName; 

    phone;
    name;

    @track
    buttonLabel
    
    // Fetch the phone number field dynamically from the database
    @wire(getRecord, { recordId: '$recordId', fields: [PHONE_FIELD, NAME_FIELD] })
    wiredRecord({ error, data }) {
        if (data) {
            this.phone = getFieldValue(data, PHONE_FIELD);
            this.name = getFieldValue(data, NAME_FIELD);
            this.buttonLabel = 'Call ' + this.name;
        } else if (error) {
            console.error('Error fetching phone field data: ', error);
        }
    }

    // Public lifecycle method triggered when the Quick Action is pushed
    //@api invoke() {
    openAircall(){
        if (!this.phone) {
            console.warn('No phone number found on this record to pass to Aircall.');
            return;
        }

        // Clean out spaces and special characters for a clean iOS deep link transition
        const sanitizedPhone = this.phone.replace(/[^0-9+]/g, '');

        // Generate and execute the deep link payload structure
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: `aircall://call?to=${sanitizedPhone}`
            }
        });
    }
}