import { LightningElement, api, wire, track } from 'lwc';
import { NavigationMixin } from "lightning/navigation";
import getProperties from '@salesforce/apex/PropertyGridController.getProperties';
import ActionsModal from 'c/actionsModal';

export default class PropertyGrid extends NavigationMixin(LightningElement) {
    @api selectedPropertyIds = [];
    properties = [];
    ringBaseClasses = 'slds-progress-ring slds-progress-ring_large custom-progress-ring';

    computePerformanceRingClass(performanceText) {
        let performanceClass = '';
        if (performanceText === 'Yellow') {
            performanceClass = 'slds-progress-ring_warning';
        } else if (performanceText === 'Red') {
            performanceClass = 'slds-progress-ring_expired';
        }
        return `${this.ringBaseClasses} ${performanceClass}`;
    }

    computeProgressRingClass(value) {
        return `${this.ringBaseClasses} ${value < 50 ? 'slds-progress-ring_warning' : ''}`;
    }

    get propertyGridClass() {
        const classes = ['property-grid'];
        if (this.properties.length === 1) {
            classes.push('property-grid--single');
        }
        return classes.join(' ');
    }
    
    @wire(getProperties, { propertyIds: '$selectedPropertyIds' })
    wiredProperties({ error, data }) {
        if (data) {
            this.properties = data.map(propertyWrapper => {
                const revenue = parseFloat(propertyWrapper.revenue); 
                const revPOS = parseFloat(propertyWrapper.revPOS);
                const vacancyLoss = parseFloat(propertyWrapper.vacancyLoss);
                const reservationPct = (propertyWrapper.property.Total_Reserved_Suites__c / propertyWrapper.property.Total_Suites__c) * 100;
                const signedLeases = propertyWrapper.property.KPI_Leases__c ? propertyWrapper.property.KPI_Leases__c : 0;
                const signedLeasePct = (signedLeases / propertyWrapper.property.Total_Suites__c) * 100;
                
                return {
                    ...propertyWrapper.property,
                    isOpen: propertyWrapper.isOpen,
                    isConstruction: propertyWrapper.isConstruction,
                    occupancyClass: this.computePerformanceRingClass(propertyWrapper.property.Performance_Text__c),
                    leadTourClass: this.computeProgressRingClass(propertyWrapper.property.KPI_Lead_Tour__c),
                    tourLeaseClass: this.computeProgressRingClass(propertyWrapper.property.KPI_Tour_Lease__c),
                    revenueLabel: `Revenue: $${revenue.toFixed(2)}`,
                    revPOSLabel: `RevPOS: $${revPOS.toFixed(2)}`,
                    vacancyLossLabel: `Vacancy Loss: $${vacancyLoss.toFixed(2)}`,
                    unpaidInvoices: propertyWrapper.unpaidInvoices.map(invoice => ({
                        Id: invoice.Id,
                        memberId: invoice.memberId,
                        memberName: invoice.memberName,
                        memberBalanceLabel: `${invoice.memberName} - $${parseFloat(invoice.unpaidBalance).toFixed(2)}`
                    })),
                    recentLeads: propertyWrapper.recentLeads.slice(0, 3).map(lead => ({
                        Id: lead.Id,
                        name: lead.name,
                        dateSubmittedLabel: `${lead.name} - ${this.formatLocalDate(lead.dateSubmitted)}`
                    })),
                    unpaidInvoicesCount: propertyWrapper.unpaidInvoices.length,
                    unpaidInvoicesSummary: propertyWrapper.unpaidInvoices.length > 5,
                    reservationStyle: `width:${reservationPct}%;`,
                    signedLeaseStyle: `width:${signedLeasePct}%; margin-left:${reservationPct}%;`,
                    reservationLeaseLabel: `${propertyWrapper.property.Total_Reserved_Suites__c + signedLeases}/${propertyWrapper.property.Total_Suites__c}`,
                    reservationLabel: `Reservations ${propertyWrapper.property.Total_Reserved_Suites__c}`,
                    signedLeaseLabel: `Leases Signed ${signedLeases}`,
                    signedLeases: signedLeases,
                    signedLeasePct: signedLeasePct,
                    occupancyD: this.calculateDAttribute(propertyWrapper.property.Occupancy_Rate__c),
                    leadTourD: this.calculateDAttribute(propertyWrapper.property.KPI_Lead_Tour__c),
                    tourLeaseD: this.calculateDAttribute(propertyWrapper.property.KPI_Tour_Lease__c),
                    reservationD: this.calculateDAttribute(reservationPct),
                    signedLeaseD: this.calculateDAttribute(signedLeasePct),
                    occupancyFill: propertyWrapper.property.Occupancy_Rate__c >= 100,
                    leadTourFill: propertyWrapper.property.KPI_Lead_Tour__c >= 100,
                    tourLeaseFill: propertyWrapper.property.KPI_Tour_Lease__c >= 100
                };
            });
        } else if (error) {
            console.error(error);
        }
    }

    formatLocalDate(dateValue) {
        if (!dateValue) {
            return '';
        }
        const [year, month, day] = String(dateValue).split('T')[0].split('-').map(Number);
        return new Date(year, month - 1, day).toLocaleDateString();
    }

    calculateDAttribute(fillPercent) {
        const isLong = fillPercent > 50 ? 1 : 0;
        const sweepFlag = 0; // 0 for Fill; 1 for Drain
        const arcX = Math.cos(2 * Math.PI * (fillPercent / 100)).toFixed(2);
        const arcY = Math.sin(2 * Math.PI * (fillPercent / 100)).toFixed(2) * -1;
        return `M 1 0 A 1 1 0 ${isLong} ${sweepFlag} ${arcX} ${arcY} L 0 0`;
    }

    handleMemberNav(event) {
        const recordId = event.target.dataset.id;
        this[NavigationMixin.Navigate]({
            type: "standard__recordPage",
            attributes: {
              recordId: recordId,
              objectApiName: "Account",
              actionName: "view",
            },
        });
    }

    async handleNavigateToPaymentCenter(event) {
        const recordName = event.target.dataset.name;
        const propertyId = event.target.dataset.propertyId;

        const result = await ActionsModal.open({
            size: 'full',
            flowName: 'Collection Center',
            recordId: propertyId,
            recordName: recordName,
            inputVariables: [
                {
                    name: 'recordId',
                    type: 'String',
                    value: propertyId
                }
            ]
        });
    }

    handlePropertyIdsChange(event) {
        this.selectedPropertyIds = event.detail.ids;
    }

    handleRecordNav(event) {
        const recordId = event.target.dataset.id;
        const object = event.target.dataset.object;

        this[NavigationMixin.Navigate]({
            type: "standard__recordPage",
            attributes: {
              recordId: recordId,
              objectApiName: object,
              actionName: "view",
            },
        });
    }
}