import { LightningElement, api, track, wire } from 'lwc';
import getCreditHistoryForMember from '@salesforce/apex/CreditHistoryController.getCreditHistoryForMember';
import getAccountCreditBalance from '@salesforce/apex/CreditHistoryController.getAccountCreditBalance';

export default class CreditHistory extends LightningElement {
    @api recordId;
    @api propertyId;
    @track credits = [];
    @track isLoading = true;
    @track creditBalance;

    @wire(getCreditHistoryForMember, { memberId: '$recordId', propertyId: '$propertyId' })
    wiredCredits({ error, data }) {
        this.isLoading = true;
        if (data) {
            this.credits = data.map(credit => ({
                ...credit,
                paymentDate: this.formatDate(credit.Payment_Date__c)
            }));
            this.isLoading = false;
        } else if (error) {
            console.error('Error fetching credit history:', error);
            this.isLoading = false;
        }
    }

    @wire(getAccountCreditBalance, { accountId: '$recordId' })
    wiredCreditBalance({ error, data }) {
        if (data !== undefined) {
            this.creditBalance = data;
        } else if (error) {
            console.error('Error fetching account credit balance:', error);
        }
    }

    formatDate(dateString) {
        if (!dateString) return '';

        const dateParts = dateString.split('-');
        if (dateParts.length === 3) {
            const [year, month, day] = dateParts;
            return `${month}/${day}/${year}`;
        }
        return dateString;
    }

    get noCredits() {
        return !this.isLoading && this.credits.length === 0;
    }
}