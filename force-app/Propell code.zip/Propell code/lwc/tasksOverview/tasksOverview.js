import { LightningElement, wire, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { refreshApex } from '@salesforce/apex';
import Id from '@salesforce/user/Id';
import getUserTasks from '@salesforce/apex/TasksOverviewController.getUserTasks';
import getDelegatedTasks from '@salesforce/apex/TasksOverviewController.getDelegatedTasks';
import updateTaskStatus from '@salesforce/apex/TasksOverviewController.updateTaskStatus';

export default class TasksOverview extends NavigationMixin(LightningElement) {
    userId = Id;
    @track isMobile = false;
    @track tasks = [];
    @track delegatedTasks = [];
    @track todayTasks = [];
    @track pastDueTasks = [];
    @track upcomingTasks = [];
    @track isRefreshing = false;
    activeSections = [];
    wiredTasks;
    lists;

    connectedCallback() {
        if (window.innerWidth <= 768) {
            this.isMobile = true;
        }
    }

    get hasDelegatedTasks() {
        return this.delegatedTasks.length > 0;
    }

    // Display 5 tasks for each section
    get topTodayTasks() {
        return this.todayTasks.slice(0, 5);
    }

    get topPastDueTasks() {
        return this.pastDueTasks.slice(0, 5);
    }

    get topUpcomingTasks() {
        return this.upcomingTasks.slice(0, 5);
    }

    get topDelegatedTasks() {
        return this.delegatedTasks.slice(0, 5);
    }

    // Determine if "View More" button should be shown
    get showMoreToday() {
        return this.todayTasks.length > 5;
    }

    get showMorePastDue() {
        return this.pastDueTasks.length > 5;
    }

    get showMoreUpcoming() {
        return this.upcomingTasks.length > 5;
    }

    get showMoreDelegated() {
        return this.delegatedTasks.length > 5;
    }

    get upcomingCardClass() {
        return this.hasDelegatedTasks ? '' : 'last-card';
    }

    handleRefresh() {
        this.isRefreshing = true;
        refreshApex(this.wiredTasks);
        setTimeout(() => {
            this.isRefreshing = false;
          }, 1000);
    }
    
    @wire(getUserTasks, { userId: '$userId' })
    wiredTasks(result) {
        this.wiredTasks = result;
        const { data, error } = result;
        if (data) {
            const today = new Date().toISOString().split('T')[0];
            this.tasks = data.map(task => {
                const isToday = task.ActivityDate === today;
                const isPastDue = task.ActivityDate < today;
                const isUpcoming = task.ActivityDate > today;
                
                return {
                    ...task,
                    isCompleted: task.Status === 'Completed',
                    WhoIdName: task.Who ? task.Who.Name : '',
                    class: task.Status === 'Completed' ? 'completed-task' : '',
                    isToday,
                    isPastDue,
                    isUpcoming
                };
            });

            this.setTasks();
            this.initializeActiveSections();
        } else if (error) {
            console.error('Error fetching tasks: ', error);
        }
    }

    @wire(getDelegatedTasks, { userId: '$userId' })
    wiredDelegatedTasks({ data, error }) {
        if (data) {
            this.delegatedTasks = data
                .filter(task => task.Status !== 'Completed')
                .map(task => {
                    return {
                        ...task,
                        isCompleted: task.Status === 'Completed',
                        WhoIdName: task.Who ? task.Who.Name : '',
                        class: task.Status === 'Completed' ? 'completed-task' : ''
                    };
                });
        } else if (error) {
            console.error('Error fetching delegated tasks: ', error);
        }
    }

    setTasks() {
        this.todayTasks = this.tasks.filter(task => task.isToday);
        this.pastDueTasks = this.tasks.filter(task => task.isPastDue);
        this.upcomingTasks = this.tasks.filter(task => task.isUpcoming);
    }

    initializeActiveSections() {
        this.activeSections = [];
        if (this.todayTasks.length > 0) {
            this.activeSections.push('today');
        }
        if (this.pastDueTasks.length > 0) {
            this.activeSections.push('pastDue');
        }
        if (this.upcomingTasks.length > 0) {
            this.activeSections.push('upcoming');
        }
    }

    get accordionLabel() {
        return `Tasks: ${this.todayTasks.length} today - ${this.pastDueTasks.length} past due - ${this.upcomingTasks.length} upcoming`;
    }

    handleTaskNav(event) {
        const recordId = event.target.dataset.id;

        this[NavigationMixin.Navigate]({
            type: "standard__recordPage",
            attributes: {
              recordId: recordId,
              objectApiName: "Task",
              actionName: "view",
            },
        });
    }

    handleMoreClick(event) {
        const filter = event.target.dataset.filter;

        this[NavigationMixin.Navigate]({
            type: 'standard__webPage', 
            attributes: {
                url: `/s/task/Task/Default?Task-filterId=${filter}`
            }
        });
    }

    handleStatusChange(event) {
        this.isRefreshing = true;
        const taskId = event.target.dataset.id;
        const newStatus = event.target.checked ? 'Completed' : 'Open';

        updateTaskStatus({ taskId, newStatus })
            .then(() => {
                // Update main tasks array
                this.tasks = this.tasks.map(task => {
                    if (task.Id === taskId) {
                        return { 
                            ...task, 
                            Status: newStatus, 
                            isCompleted: newStatus === 'Completed',
                            class: newStatus === 'Completed' ? 'completed-task' : ''
                        };
                    }
                    return task;
                });

                // Update delegated tasks array
                this.delegatedTasks = this.delegatedTasks.map(task => {
                    if (task.Id === taskId) {
                        return { 
                            ...task, 
                            Status: newStatus, 
                            isCompleted: newStatus === 'Completed',
                            class: newStatus === 'Completed' ? 'completed-task' : ''
                        };
                    }
                    return task;
                });

                this.setTasks();
                this.isRefreshing = false;
            })
            .catch(error => {
                console.error('Error updating task status:', error);
                this.isRefreshing = false;
            });
    }

    handleTaskListNav() {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage', 
            attributes: {
                url: `/s/task/Task/Default`
            }
        });
    }
}