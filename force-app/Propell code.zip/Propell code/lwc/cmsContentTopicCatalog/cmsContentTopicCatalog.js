import { LightningElement, wire, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getManagedTopics from '@salesforce/apex/ManagedContentController.getManagedTopics';
import basePath from '@salesforce/community/basePath';


export default class CmsContentTopicCatalog extends NavigationMixin (LightningElement) {
    @api recordId;
    @api topicId;
    @api listHeader;

    error;
    topicsArray;
    topicsString;
    topicsToTweak;
    topics;
    
    @wire(getManagedTopics, {recordId: '$topicId'})
    wiredTopics ({ error, data }) {
        if (error) {
            this.error = 'Unknown error';
            this.topics = undefined;
        } else if (data) {
            this.cleanUpForDisplay(data);
        } 

        console.log('CMS Debug - Topics:')
        console.log(this.topics);
    }

    //Private function to do all the data massaging
    cleanUpForDisplay(data) {
   
        //Grab data
        this.topicsArray = data;
        this.topicsString = JSON.stringify(this.topicsArray);

        //Logs
        console.log('CMS Topics Debug || Topic Array: ');
        console.log(this.topicsString);

        //Temporarily hold items
        let topicsToTweak = [];

        for (let mtopic of this.topicsArray.managedTopics) {
            //Clone the original mangedTopic object json
            let topicToAdd = JSON.parse(JSON.stringify(mtopic));
            let childrenToAdd = [];

            for (let child of topicToAdd.children) {
                let childToAdd = child;
                childToAdd.link = basePath + '/topic/' + child.topic.id;
                childToAdd.title = this.htmlDecode(child.topic.name);

                let children2ToAdd = [];

                for (let child2 of child.children){
                    let child2ToAdd = child2;
                    child2ToAdd.link = basePath + '/topic/' + child2.topic.id;
                    child2ToAdd.title = this.htmlDecode(child2.topic.name);
                    children2ToAdd.push(child2ToAdd);
                }

                childToAdd.Children = children2ToAdd;
                childrenToAdd.push(childToAdd);

            }
            topicToAdd.children = childrenToAdd;

            //Add to array
            topicsToTweak.push(topicToAdd);
        }
        //Assign Topics
        this.topics = topicsToTweak;
  
    }
    //Private function to decode HTML
    htmlDecode(input) {
        var doc = new DOMParser().parseFromString(input, 'text/html');
        return doc.documentElement.textContent;
     }
}