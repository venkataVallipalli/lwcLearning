import { LightningElement, track } from 'lwc';

export default class ErrorDisplay extends LightningElement {
    @track errorDescription;
    loginURL;

    connectedCallback() {
        this.parseUrl();
    }

    parseUrl() {
        // Parse the full URL
        const fullUrl = new URL(window.location.href);
        const baseUrl = `${fullUrl.protocol}//${fullUrl.host}`; // Base URL

        // Parse the query string parameters
        const urlParams = new URLSearchParams(fullUrl.search);
        
        // Get the error description from the URL
        const errorDescriptionEncoded = urlParams.get('ErrorDescription');
        if (errorDescriptionEncoded) {
            let decodedError =  decodeURIComponent(errorDescriptionEncoded.replace(/\+/g, ' '));
            let errorAndLoginUrl = decodedError.split('loginURL');
            this.errorDescription = errorAndLoginUrl[0];
            this.loginURL = errorAndLoginUrl[1];
        }

        // Log the extracted values to the console
        console.log('Error Description:', this.errorDescription);
        console.log('Login URL:', this.loginURL);
    }
}