import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getPropertyByStoreNumber from '@salesforce/apex/PropertyController.getPropertyByStoreNumber';

export default class PropertyLocator extends NavigationMixin(LightningElement) {
    @api storeNumber = ''; // Use @api to expose the property if you want to make it public

    handleInputChange(event) {
        this.storeNumber = event.target.value;
    }

    handleSearch() {
        if (this.storeNumber) {
            getPropertyByStoreNumber({ storeNumber: this.storeNumber })
                .then(result => {
                    if (result) {
                        // Navigate to the record page
                        this[NavigationMixin.Navigate]({
                            type: 'standard__recordPage',
                            attributes: {
                                recordId: result.Id,
                                objectApiName: 'Property__c', // Ensure this is the correct API name for your custom object
                                actionName: 'view'
                            }
                        });
                    } else {
                        // Handle no matching record found
                        this.dispatchEvent(
                            new ShowToastEvent({
                                title: 'Not Found',
                                message: 'No property found for store number: ' + this.storeNumber,
                                variant: 'warning'
                            })
                        );
                    }
                })
                .catch(error => {
                    // Handle the error
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error',
                            message: 'Error retrieving property: ' + error.body.message,
                            variant: 'error'
                        })
                    );
                });
        } else {
            // Handle case where storeNumber is empty
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Store number cannot be empty.',
                    variant: 'error'
                })
            );
        }
    }

    handleKeyUp(event) {
        if (event.keyCode === 13) {
            this.handleSearch();
        }
    }
}