import { LightningElement, api, track, wire } from 'lwc';
import getCollectionCenterRecords from '@salesforce/apex/PaymentOverviewController.getCollectionCenterRecords';
import getRecentPaymentCounts from '@salesforce/apex/PaymentOverviewController.getRecentPaymentCounts';
import getNewAgreementsThisWeek from '@salesforce/apex/PaymentOverviewController.getNewAgreementsThisWeek';
import getOneTimeInvoicesThisWeekNextWeek from '@salesforce/apex/PaymentOverviewController.getOneTimeInvoicesThisWeekNextWeek';
import getExpiringOpportunitiesNextWeek from '@salesforce/apex/PaymentOverviewController.getExpiringOpportunitiesNextWeek';
import getOpportunitiesNotOnAutopay from '@salesforce/apex/PaymentOverviewController.getOpportunitiesNotOnAutopay';
import ActionsModal from 'c/actionsModal';
import { NavigationMixin } from "lightning/navigation";

export default class PaymentOverview extends NavigationMixin(LightningElement) {
    @track collectionCenterData;
    @track collectionCenterCount;
    @track recentPaymentsToday;
    @track recentPaymentsLastSevenDays;
    @track newAgreementsThisWeekData;
    @track oneTimeInvoicesThisWeekNextWeekData;
    @track expiringOpportunitiesNextWeekData;
    @track opportunitiesNotOnAutopayData;
    @api selectedPropertyIds = [];
    @api selectedProperties = [];
    @track isDesktopView = false;
    @track breakpointWidth = 768;
    @track activeSections = [
        'collectionCenter',
        'newAgreementsThisWeek',
        'oneTimeInvoicesThisWeekNextWeek',
        'expiringNextWeek',
        'notOnAutopay'
    ];

    get collectionCenterTitle() {
        return `COLLECTION CENTER (${this.collectionCenterCount || 0})`;
    }

    get newAgreementsTitle() {
        return `NEW AGREEMENTS THIS WEEK (${this.newAgreementsThisWeekData?.length || 0})`;
    }

    get oneTimeInvoicesTitle() {
        return `ONE-TIME INVOICES THIS WEEK / NEXT WEEK (${this.oneTimeInvoicesThisWeekNextWeekData?.length || 0})`;
    }

    get expiringOpportunitiesTitle() {
        return `EXPIRING NEXT WEEK (${this.expiringOpportunitiesNextWeekData?.length || 0})`;
    }

    get notOnAutopayTitle() {
        return `NOT ON AUTOPAY (${this.opportunitiesNotOnAutopayData?.length || 0})`;
    }

    handlePropertyIdsChange(event) {
        this.selectedPropertyIds = event.detail.ids;
        this.selectedProperties = event.detail.properties;
    }

    connectedCallback() {
        this.checkViewport();
        window.addEventListener('resize', this.handleResize.bind(this));
    }

    disconnectedCallback() {
        window.removeEventListener('resize', this.handleResize.bind(this));
    }

    handleResize() {
        this.checkViewport();
    }

    checkViewport() {
        this.isDesktopView = window.innerWidth >= this.breakpointWidth;
    }

    @wire(getCollectionCenterRecords, { propertyIds: '$selectedPropertyIds' })
    wiredCollectionCenterData({ error, data }) {
        if (data) {
            console.log('data', JSON.stringify(data));
            this.collectionCenterCount = data.length;
            this.collectionCenterData = this.processCollectionCenterRecords(data);
        } else if (error) {
            this.collectionCenterData = [];
            this.collectionCenterCount = 0;
            console.error('Error fetching collection center data:', error);
        }
    }

    @wire(getRecentPaymentCounts, { propertyIds: '$selectedPropertyIds' })
    wiredRecentPaymentData({ error, data }) {
        if (data) {
            this.recentPaymentsToday = data.paymentsToday;
            this.recentPaymentsLastSevenDays = data.paymentsLastSevenDays;
        } else if (error) {
            this.recentPaymentsToday = undefined;
            this.recentPaymentsLastSevenDays = undefined;
            console.error('Error fetching recent payment counts:', error);
        }
    }

    @wire(getNewAgreementsThisWeek, { propertyIds: '$selectedPropertyIds' })
    wiredNewAgreementsThisWeekData({ error, data }) {
        if (data) {
            this.newAgreementsThisWeekData = this.processRecords(data);
        } else if (error) {
            this.newAgreementsThisWeekData = [];
            console.error('Error fetching new agreements this week data:', error);
        }
    }

    @wire(getOneTimeInvoicesThisWeekNextWeek, { propertyIds: '$selectedPropertyIds' })
    wiredOneTimeInvoicesThisWeekNextWeekData({ error, data }) {
        if (data) {
            this.oneTimeInvoicesThisWeekNextWeekData = this.processRecords(data);
        } else if (error) {
            this.oneTimeInvoicesThisWeekNextWeekData = [];
            console.error('Error fetching one-time invoices this week/next week data:', error);
        }
    }

    @wire(getExpiringOpportunitiesNextWeek, { propertyIds: '$selectedPropertyIds' })
    wiredExpiringOpportunitiesNextWeekData({ error, data }) {
        if (data) {
            this.expiringOpportunitiesNextWeekData = this.processRecords(data);
        } else if (error) {
            this.expiringOpportunitiesNextWeekData = [];
            console.error('Error fetching expiring opportunities next week data:', error);
        }
    }

    @wire(getOpportunitiesNotOnAutopay, { propertyIds: '$selectedPropertyIds' })
    wiredOpportunitiesNotOnAutopayData({ error, data }) {
        if (data) {
            this.opportunitiesNotOnAutopayData = this.processRecords(data);
        } else if (error) {
            this.opportunitiesNotOnAutopayData = [];
            console.error('Error fetching opportunities not on autopay data:', error);
        }
    }

    processRecords(records) {
        return records.map(record => {
            const property = this.selectedProperties.find(prop => prop.Id === record.propertyId);
            return {
                ...record,
                propertyStyle: property ? property.style : '',
                propertyAbbr: property ? property.abbr : '',
                invoiceDate: this.formatDate(record.invoiceDate),
                agreementStartDate: this.formatDate(record.agreementStartDate),
                agreementEndDate: this.formatDate(record.agreementEndDate)
            }
        });
    }

    processCollectionCenterRecords(records) {
        let groupedRecords = {};
        records.forEach(record => {
            const property = this.selectedProperties.find(prop => prop.Id === record.propertyId);
            if (property) {
                if (!groupedRecords[property.Id]) {
                    groupedRecords[property.Id] = {
                        id: property.Id,
                        propertyName: property.Name,
                        invoices: [],
                        showButton: false,
                        noInvoices: false,
                        propertyId: property.Id // Store the property ID for sorting
                    };
                }
                const formattedRecord = {
                    ...record,
                    propertyStyle: property.style,
                    propertyAbbr: property.abbr,
                    invoiceDate: this.formatDate(record.invoiceDate),
                    agreementStartDate: this.formatDate(record.agreementStartDate),
                    agreementEndDate: this.formatDate(record.agreementEndDate)
                };
                groupedRecords[property.Id].invoices.push(formattedRecord);
            }
        });

        // Determine which properties should show the button
        Object.keys(groupedRecords).forEach(propertyId => {
            groupedRecords[propertyId].showButton = groupedRecords[propertyId].invoices.length > 5;
        });

        // Order grouped records by selectedProperties order 
        let orderedGroupedRecords = this.selectedProperties.map(property => groupedRecords[property.Id] || {
            id: property.Id,
            propertyName: property.Name,
            invoices: [],
            showButton: false,
            noInvoices: true
        });
        return orderedGroupedRecords;
    }

    async handleMakePayment(event) {
        const recordId = event.target.dataset.id;

        this[NavigationMixin.Navigate]({
            type: "standard__quickAction",
            attributes: {
                apiName: 'Invoice__c.Process_Payment'
            },
            state: {
                objectApiName: 'Invoice__c',
                context: "RECORD_DETAIL",
                recordId: recordId,
                backgroundContext: "/lightning/r/Invoice__c/" + recordId + "/view"
            }
        });

    }

    get inputVariables() {
        return [
            {
                name: 'recordId',
                type: 'String',
                value: '006E1000006kHqRIAU'
            }
        ];
    }

    async handleAddPaymentMethod(event) {
        const recordId = event.target.dataset.id;
        const recordName = event.target.dataset.name;

        const result = await ActionsModal.open({
            size: 'full',
            flowName: 'MRA',
            recordId: recordId,
            recordName: recordName,
            inputVariables: [
                {
                    name: 'recordId',
                    type: 'String',
                    value: recordId
                }
            ]
        });
    }

    handleRecordNav(event) {
        const recordId = event.currentTarget.dataset.id;
        const sObject = event.currentTarget.dataset.sobject;
        
        this[NavigationMixin.Navigate]({
            type: "standard__recordPage",
            attributes: {
              recordId: recordId,
              objectApiName: sObject,
              actionName: "view",
            },
        });
    }

    async handleNavigateToPaymentCenter(event) {
        const recordName = event.target.dataset.name;
        const propertyId = event.target.dataset.propertyId;

        const result = await ActionsModal.open({
            size: 'full',
            flowName: 'Collection Center',
            recordId: propertyId,
            recordName: recordName,
            inputVariables: [
                {
                    name: 'recordId',
                    type: 'String',
                    value: propertyId
                }
            ]
        });
    }

    formatDate(dateString) {
        if (!dateString) return '';

        const dateParts = dateString.split('-');
        if (dateParts.length === 3) {
            const [year, month, day] = dateParts;
            return `${month}/${day}/${year}`;
        }
        return dateString;
    }

    get isCollectionCenterEmpty() {
        return this.collectionCenterData && this.collectionCenterData.length === 0;
    }

    get isNewAgreementsEmpty() {
        return this.newAgreementsThisWeekData && this.newAgreementsThisWeekData.length === 0;
    }

    get isOneTimeInvoicesEmpty() {
        return this.oneTimeInvoicesThisWeekNextWeekData && 
               this.oneTimeInvoicesThisWeekNextWeekData.length === 0;
    }

    get isExpiringOpportunitiesEmpty() {
        return this.expiringOpportunitiesNextWeekData && 
               this.expiringOpportunitiesNextWeekData.length === 0;
    }

    get isNotOnAutopayEmpty() {
        return this.opportunitiesNotOnAutopayData && 
               this.opportunitiesNotOnAutopayData.length === 0;
    }
}