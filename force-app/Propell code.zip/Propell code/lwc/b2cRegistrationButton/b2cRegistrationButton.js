import { LightningElement, api, wire } from 'lwc';
import { getFieldValue, getRecord } from 'lightning/uiRecordApi';
import Id from '@salesforce/user/Id';
import ContactId from '@salesforce/schema/User.ContactId'; 
import LinkField from '@salesforce/schema/User.Contact.Account.B2C_Registration_Form_URL__c';
import Email from '@salesforce/schema/User.Email';

export default class UserAccount extends LightningElement {
    @api buttonTextGo;
    @api buttonTextLogIn;
    
    userId = Id;
    
    @wire (getRecord, { recordId: Id, fields: [Email], optionalFields: [LinkField,ContactId] })
        user;

    get btnLink(){
        if (getFieldValue(this.user.data, LinkField) != null) {
            return getFieldValue(this.user.data, LinkField);
        }   else { 
            return '/s/login/?ec=302&startURL=%2Fs%2Fbeyond-the-suite';
        }
    }
    get buttonText(){
        if (getFieldValue(this.user.data, LinkField) != null) {
            return this.buttonTextGo;
        }   else { 
            return this.buttonTextLogIn;
        }
    }
}