import { api, LightningElement, wire } from 'lwc';
import { getFieldValue, getRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { loadScript } from 'lightning/platformResourceLoader';
import FORM_FACTOR from '@salesforce/client/formFactor';
import LEAD_PHONE from '@salesforce/schema/Lead.Phone';

const AIRCALL_MOBILE_PAGE = '/apex/AircallMobile';
const OPEN_CTI_SCRIPT = '/support/api/67.0/lightning/opencti_min.js';
const E164_PHONE_PATTERN = /^\+[1-9]\d{7,14}$/;
const DEFAULT_COUNTRY_CODE = '1';
const LOG_PREFIX = '[OpenLeadInAircall]';

export default class OpenLeadInAircall extends LightningElement {
    @api recordId;

    lead;
    loadError;
    openCtiPromise;
    isOpening = false;

    @wire(getRecord, { recordId: '$recordId', fields: [LEAD_PHONE] })
    wiredLead({ data, error }) {
        console.log(`${LOG_PREFIX} wiredLead response`, {
            recordId: this.recordId,
            hasData: !!data,
            hasError: !!error,
            error
        });

        this.lead = data;
        this.loadError = error;
    }

    @api
    async invoke() {
        console.log(`${LOG_PREFIX} invoke started`, {
            recordId: this.recordId,
            isOpening: this.isOpening,
            hasLead: !!this.lead,
            hasLoadError: !!this.loadError,
            formFactor: FORM_FACTOR
        });

        if (this.isOpening) {
            console.log(`${LOG_PREFIX} invoke skipped because an open request is already running`);
            return;
        }

        if (this.loadError) {
            console.error(`${LOG_PREFIX} Lead load error`, this.loadError);
            this.showError('The Lead phone number could not be loaded.');
            return;
        }

        if (!this.lead) {
            console.warn(`${LOG_PREFIX} Lead data is not ready yet`);
            this.showError('The Lead is still loading. Please try again.');
            return;
        }

        const rawPhone = getFieldValue(this.lead, LEAD_PHONE);
        const phone = this.normalizePhone(rawPhone);
        console.log(`${LOG_PREFIX} phone normalized`, {
            rawPhone,
            normalizedPhone: phone
        });

        if (!phone) {
            console.warn(`${LOG_PREFIX} no usable phone number found`);
            this.showError('Add a phone number to the Lead before opening Aircall.');
            return;
        }

        if (!E164_PHONE_PATTERN.test(phone)) {
            console.warn(`${LOG_PREFIX} phone failed E.164 validation`, {
                rawPhone,
                normalizedPhone: phone
            });
            this.showError(
                'Enter the Lead phone number in international format, for example +14155552671.'
            );
            return;
        }

        this.isOpening = true;

        try {
            if (this.isMobileFormFactor()) {
                this.openAircallMobileRedirect('mobile form factor detected');
                return;
            }

            console.log(`${LOG_PREFIX} loading Open CTI`);
            await this.loadOpenCti();
            console.log(`${LOG_PREFIX} Open CTI loaded, dialing`, { phone });
            await this.openAircallAndDial(phone);
            console.log(`${LOG_PREFIX} clickToDial completed`, { phone });
            this.showToast('Aircall opened', `Aircall is ready to call ${phone}.`, 'success');
        } catch (error) {
            console.error(`${LOG_PREFIX} Aircall open failed`, error);

            if (this.shouldFallbackToDeepLinkRedirect()) {
                this.openAircallMobileRedirect('Open CTI unavailable, using Aircall deep link fallback');
                return;
            }

            this.showError(this.getErrorMessage(error));
        } finally {
            console.log(`${LOG_PREFIX} invoke finished`);
            this.isOpening = false;
        }
    }

    isMobileFormFactor() {
        return FORM_FACTOR === 'Small' || FORM_FACTOR === 'Medium';
    }

    shouldFallbackToDeepLinkRedirect() {
        const shouldFallback = !window.sforce?.opencti;

        console.log(`${LOG_PREFIX} checking deep link fallback`, {
            shouldFallback,
            hasOpenCti: !!window.sforce?.opencti,
            formFactor: FORM_FACTOR
        });

        return shouldFallback;
    }

    openAircallMobileRedirect(reason) {
        const redirectUrl = `${AIRCALL_MOBILE_PAGE}?id=${encodeURIComponent(this.recordId)}`;

        console.log(`${LOG_PREFIX} redirecting to Visualforce Aircall launcher`, {
            reason,
            formFactor: FORM_FACTOR,
            redirectUrl
        });

        window.location.href = redirectUrl;
    }

    loadOpenCti() {
        if (window.sforce?.opencti) {
            console.log(`${LOG_PREFIX} Open CTI already exists on window.sforce`);
            return Promise.resolve();
        }

        if (!this.openCtiPromise) {
            console.log(`${LOG_PREFIX} loading Open CTI script`, { script: OPEN_CTI_SCRIPT });
            this.openCtiPromise = loadScript(this, OPEN_CTI_SCRIPT)
                .then(() => {
                    console.log(`${LOG_PREFIX} Open CTI script load resolved`, {
                        hasOpenCti: !!window.sforce?.opencti
                    });

                    if (!window.sforce?.opencti) {
                        throw new Error('Salesforce Open CTI is not available in this app.');
                    }
                })
                .catch((error) => {
                    console.error(`${LOG_PREFIX} Open CTI script load failed`, error);
                    this.openCtiPromise = undefined;
                    throw error;
                });
        } else {
            console.log(`${LOG_PREFIX} reusing existing Open CTI load promise`);
        }

        return this.openCtiPromise;
    }

    openAircallAndDial(phone) {
        console.log(`${LOG_PREFIX} opening softphone panel`);

        return new Promise((resolve, reject) => {
            window.sforce.opencti.setSoftphonePanelVisibility({
                visible: true,
                callback: (panelResponse) => {
                    console.log(`${LOG_PREFIX} setSoftphonePanelVisibility response`, panelResponse);

                    if (panelResponse?.success === false) {
                        reject(new Error(this.getOpenCtiErrorMessage(panelResponse)));
                        return;
                    }

                    console.log(`${LOG_PREFIX} calling clickToDial`, { phone });
                    window.sforce.opencti.clickToDial({
                        number: phone,
                        callback: (dialResponse) => {
                            console.log(`${LOG_PREFIX} clickToDial response`, dialResponse);

                            if (dialResponse?.success === false) {
                                reject(new Error(this.getOpenCtiErrorMessage(dialResponse)));
                                return;
                            }

                            resolve();
                        }
                    });
                }
            });
        });
    }

    normalizePhone(phone) {
        if (!phone) {
            return '';
        }

        const trimmedPhone = String(phone).trim();
        const internationalPhone = trimmedPhone.startsWith('00')
            ? `+${trimmedPhone.slice(2)}`
            : trimmedPhone;

        if (internationalPhone.startsWith('+')) {
            return `+${internationalPhone.slice(1).replace(/\D/g, '')}`;
        }

        const digits = internationalPhone.replace(/\D/g, '');

        if (digits.length === 10) {
            return `+${DEFAULT_COUNTRY_CODE}${digits}`;
        }

        if (digits.length === 11 && digits.startsWith(DEFAULT_COUNTRY_CODE)) {
            return `+${digits}`;
        }

        return digits ? `+${digits}` : '';
    }

    getOpenCtiErrorMessage(response) {
        return response.errors?.length
            ? response.errors
                  .map((error) => error.description || error.message || error.statusCode)
                  .join(', ')
            : 'Aircall CTI could not start the call.';
    }

    getErrorMessage(error) {
        if (error?.message) {
            return error.message;
        }

        if (typeof error === 'string') {
            return error;
        }

        return 'Aircall CTI could not start the call.';
    }

    showError(message) {
        console.error(`${LOG_PREFIX} showing error toast`, { message });
        this.showToast('Unable to open Aircall', message, 'error');
    }

    showToast(title, message, variant) {
        console.log(`${LOG_PREFIX} showing toast`, {
            title,
            message,
            variant
        });

        this.dispatchEvent(
            new ShowToastEvent({
                title,
                message,
                variant
            })
        );
    }
}