import { LightningElement, api } from 'lwc';

export default class CustomKanbanColumn extends LightningElement {
    @api sObjectName;
    @api records;
    @api status;

    get statusField() {
        return this.sObjectName === 'Lead' ? 'Status' : 'StageName';
    }

    get filteredRecords() {
        return this.records.filter(record => 
            record[this.statusField] === this.status
        );
    }

    handleItemDrag(event) {
        // Bubble up the event to the parent component
        this.dispatchEvent(new CustomEvent('listitemdrag', {
            detail: event.detail
        }));
    }

    handleDragOver(event) {
        event.preventDefault();
    }

    handleDrop(event) {
        event.preventDefault();
        this.dispatchEvent(new CustomEvent('itemdrop', {
            detail: {
                newStatus: this.status
            }
        }));
    }
}