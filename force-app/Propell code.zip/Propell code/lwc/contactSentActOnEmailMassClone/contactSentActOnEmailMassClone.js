import { LightningElement, wire, track } from 'lwc';
import getAccounts from '@salesforce/apex/PaginationDemoController.getAccounts';
import getTotalAccountsCount from '@salesforce/apex/PaginationDemoController.getTotalAccountsCount';
const COLUMNS = [
    { label: 'Name', fieldName: 'Name' },
    { label: 'Email', fieldName: 'Email' },
    { label: 'Title', fieldName: 'Title' },
    { label: 'Phone', fieldName: 'Phone'},
   

];

export default class contactSentActOnEmailMassClone extends LightningElement {
    columns = COLUMNS;
  @track  isLoading = true;
   @track isLoadings= false;
    records = [];
    @track selectedIds = new Set();  // Using a Set to store unique selected IDs across pages
    @track showIframe = false;

    // PAGINATION PROPERTIES
    recordsToDisplay = [];
    pageSize = 10;
    pageNumber = 1;
    totalRecords = 0;
    enablePagination = true;
    lastRecordId = '';

    get hasRecords() {
        return this.records.length > 0;
    }

    // PAGINATION PROPERTY - CHECK WHETHER PAGINATION NEEDS TO SHOW OR NOT
    get showPaginator() {
        return this.enablePagination && this.hasRecords;
    }

    // GET TOTAL RECORDS COUNT
    @wire(getTotalAccountsCount)
    wiredGetTotalAccountsCount(result) {
        if (result.data) {
            this.totalRecords = parseInt(result.data);
        } else if (result.error) {
            console.log('Error while fetching total count- ', result.error);
        }
    }

    connectedCallback() {
        this.fetchRecordsFromServer();
        console.log('url: ', window.location.origin);
    }

    async fetchRecordsFromServer() {
        try {
            let response = await getAccounts({ pageSize: this.pageSize, lastRecordId: this.lastRecordId });
            this.isLoading = false;
            this.recordsToDisplay = response;
            this.records = [...this.records, ...this.recordsToDisplay];

            // Pre-select rows if their IDs were previously selected
            this.template.querySelector('lightning-datatable').selectedRows = [...this.selectedIds];
        } catch (err) {
            this.isLoading = false;
            console.log('Error while fetching data- ', JSON.stringify(err));
        }
    }

    handleRowSelection(event) {
        const selectedRows = event.detail.selectedRows;

        // Add new selected row IDs to the Set (preserves unique IDs)
        selectedRows.forEach(row => this.selectedIds.add(row.Id));
       
        // Remove deselected row IDs from the Set
        const allRowIds = this.recordsToDisplay.map(row => row.Id);
        allRowIds.forEach(id => {
            if (!selectedRows.some(row => row.Id === id)) {
                this.selectedIds.delete(id);  // Remove ID if not selected anymore
            }
        });
    }

    // WILL AUTOMATICALLY BE CALLED FROM PAGINATOR ON PAGE NUMBER OR SIZE CHANGE
    paginationChangeHandler(event) {
        if (event.detail) {
            if (this.pageSize != event.detail.pageSize) {
                this.records = []; // RESET RECORDS ARRAY ON PAGE SIZE CHANGE...
                this.pageSize = event.detail.pageSize;
            }
            this.pageNumber = event.detail.pageNumber;

            if (this.records.length > this.pageSize * (this.pageNumber - 1)) {  // GET AND SHOW DATA FROM RECORDS LIST...
                let from = (this.pageNumber - 1) * this.pageSize,
                    to = this.pageSize * this.pageNumber;
                this.recordsToDisplay = this.records?.slice(from, to);
            } else {  // GET MORE DATA FROM SERVER...
                this.lastRecordId = this.records[this.records.length - 1]?.Id;
                this.isLoading = true;
                this.fetchRecordsFromServer();
            }
        }
    }

    handleSendToVF() {
        const selectedIdsString = [...this.selectedIds].join(',');  // Convert Set to array and join
console.log('-->'+this.selectedIds);
        if (this.selectedIds.size > 0) {
            this.isLoadings = true;

            // Store selected IDs in localStorage or send to iframe
            localStorage.setItem('selectedRecordIds', JSON.stringify([...this.selectedIds]));

            // Show the iframe after storing the IDs
            this.showIframe = true;

            setTimeout(() => {
                // Once the iframe is displayed, send the selected data to VF page
                const vfWindow = this.template.querySelector("iframe").contentWindow;

                // Wait for the iframe to load before sending the message
                setTimeout(() => {
                    const currentOrigin = window.location.origin;
                    vfWindow.postMessage(selectedIdsString, `${currentOrigin}/apex/Contact_Sent_ActOn_Email_MassClone`);
                    // vfWindow.postMessage(selectedIdsString, 'https://suite--dev.sandbox.my.site.com/apex/Contact_Sent_ActOn_Email_MassClone');
                    this.isLoadings = false;
                    this.selectedIds.clear();
                    const datatable = this.template.querySelector('lightning-datatable');
                if (datatable) {
                    datatable.selectedRows = [];  // Deselect rows
                }
                  
                }, 5000);  // Give some time for the iframe to load
           
            }, 2000);

             

        } else {
            alert('No records selected');
        }
    }
}