trigger ContentDocumentLinkChangeTrigger on ContentDocumentLink (before insert) {
    for(ContentDocumentLink cdl : Trigger.New){
    String sObjectName = cdl.LinkedEntityId.getSObjectType().getDescribe().getName();
        if (sObjectName != null && sObjectName.equalsIgnoreCase('Property__c') ) {
            cdl.Visibility = 'InternalUsers';   
        } else {
            cdl.Visibility = 'AllUsers';
        }
    }
}