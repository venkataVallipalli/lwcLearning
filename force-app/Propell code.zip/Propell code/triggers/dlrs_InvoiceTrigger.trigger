/**
 * Auto Generated and Deployed by the Declarative Lookup Rollup Summaries Tool package (dlrs)
 **/
trigger dlrs_InvoiceTrigger on Invoice__c
    (before delete, before insert, before update, after delete, after insert, after undelete, after update)
{
    if (!dlrs_Bypass.bypassInvoiceDLRS) {
    	dlrs.RollupService.triggerHandler(Invoice__c.SObjectType);
    }
}