/**
 * Auto Generated and Deployed by the Declarative Lookup Rollup Summaries Tool package (dlrs)
 **/
trigger dlrs_Corporate_Event_AttendeeTrigger on Corporate_Event_Attendee__c
    (before delete, before insert, before update, after delete, after insert, after undelete, after update)
{
    dlrs.RollupService.triggerHandler(Corporate_Event_Attendee__c.SObjectType);
}