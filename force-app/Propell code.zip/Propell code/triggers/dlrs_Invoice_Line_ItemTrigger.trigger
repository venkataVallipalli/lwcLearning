/**
 * Auto Generated and Deployed by the Declarative Lookup Rollup Summaries Tool package (dlrs)
 **/
trigger dlrs_Invoice_Line_ItemTrigger on Invoice_Line_Item__c
    (before delete, before insert, before update, after delete, after insert, after undelete, after update)
{	
    if (!dlrs_Bypass.bypassInvoiceLineItemDLRS) {
    	dlrs.RollupService.triggerHandler(Invoice_Line_Item__c.SObjectType);
    }
}