trigger UMP_WorkflowAutomationRequestTrigger on UMP_Workflow_Automation_Request__e (after insert) {
    UMP_StartWorkflowInvocable.handleWorkflowRequests(Trigger.New);
}