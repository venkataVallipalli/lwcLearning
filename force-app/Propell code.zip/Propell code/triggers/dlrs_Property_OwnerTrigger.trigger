/**
 * Auto Generated and Deployed by the Declarative Lookup Rollup Summaries Tool package (dlrs)
 **/
trigger dlrs_Property_OwnerTrigger on Property_Owner__c
    (before delete, before insert, before update, after delete, after insert, after undelete, after update)
{
    if (!dlrs_Bypass.bypassPropertyOwnerDLRS) {
        dlrs.RollupService.triggerHandler(Property_Owner__c.SObjectType);
    }
}