({

    getIdFromPageReference: function(component, myPageRef) {
        var recordId = myPageRef.state.c__recordId; 
        if(recordId){
            component.set("v.recordId", recordId );
        }
    }
})