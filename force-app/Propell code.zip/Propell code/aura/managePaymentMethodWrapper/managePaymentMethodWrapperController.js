({
    initAction : function(component, event, helper) {
        var sObjectName = component.get("v.sObjectName");
        // Use the force:createRecord event to open the standard new record modal
        // var createRecordEvent = $A.get("e.force:createRecord");
        
        // if (false && createRecordEvent) {
        //     createRecordEvent.setParams({
        //         "entityApiName": sObjectName ? sObjectName : "Account", // Use dynamic object name or default to Account
        //         "defaultFieldValues": {
        //             // Pre-populate fields if needed, e.g., 'Name': 'Default Name'
        //         },
        //         "panelOnDestroyCallback": function() {
        //             // Optional: Add logic here for when the modal is closed
        //         }
        //     });
        //     createRecordEvent.fire();
        // } else {
        //     // Fallback for older Salesforce versions or different contexts
        //     alert("The force:createRecord event is not supported in this context.");
        // }

        let oavar = "foo";

        var url = window.location.href;
        var parentId = null;

        console.log("Current URL: " + url);

        // Check for "context" parameter which often holds encoded values
        if (url.includes("inContextOfRef")) {
            var context = url.split("inContextOfRef=")[1];
            let splitContext = context.split(".")[1];

            let splitContext2 = splitContext.substring(0, splitContext.indexOf("&") !== -1 ? splitContext.indexOf("&") : splitContext.length)
            let decodedUriComponent = decodeURIComponent(splitContext2);
            let jsonString = window.atob(decodedUriComponent);

            var jsonObj = JSON.parse(jsonString);

            // The parent record ID is often in the "parentId" or "recordId" key within the decoded context
            parentId = jsonObj.attributes.recordId;
        }
        

        if (parentId) {

            console.log("Parent Record ID is: " + parentId);
            component.set("v.recordId", parentId);
        } else {

            var myPageRef = component.get("v.pageReference");

            if(myPageRef){
                helper.getIdFromPageReference(component, myPageRef);
            }else{
                console.log("Parent ID not found in URL.");

                let params = new URLSearchParams(window.location.search);
                let recordId = params.get('recordId');
                component.set("v.recordId", recordId);
            }
        }

    },

    onRecordIdChange : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        if (recordId) {
            // Now you can safely use the recordId
            console.log("Record ID is: " + recordId);
            // Call helper methods or perform logic here
        }
    },

    onPageReferenceChange: function(component, evt, helper) {
        var myPageRef = component.get("v.pageReference");
        helper.getIdFromPageReference(component, myPageRef);
    }

})