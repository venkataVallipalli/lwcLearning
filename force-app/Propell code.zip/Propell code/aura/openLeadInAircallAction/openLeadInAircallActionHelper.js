({
    mobileAircallPage: '/apex/AircallMobile',

    tryOpenAircall: function (component) {
        if (component.get('v.hasOpened') || !component.get('v.scriptLoaded')) {
            return;
        }

        if (component.get('v.recordError')) {
            this.showToast('Unable to open Aircall', 'The Lead phone number could not be loaded.', 'error');
            this.closeQuickAction();
            return;
        }

        var lead = component.get('v.lead');
        if (!lead) {
            return;
        }

        var phone = this.normalizePhone(lead.Phone);
        if (!phone) {
            this.showToast('Unable to open Aircall', 'Add a phone number to the Lead before opening Aircall.', 'error');
            this.closeQuickAction();
            return;
        }

        if (!window.sforce || !window.sforce.opencti) {
            component.set('v.hasOpened', true);
            this.openMobileAircallPage(component.get('v.recordId'));
            return;
        }

        component.set('v.hasOpened', true);
        this.openAircallAndDial(phone);
    },

    openAircallAndDial: function (phone) {
        var helper = this;

        window.sforce.opencti.setSoftphonePanelVisibility({
            visible: true,
            callback: $A.getCallback(function (panelResponse) {
                if (panelResponse && panelResponse.success === false) {
                    helper.showToast('Unable to open Aircall', helper.getOpenCtiErrorMessage(panelResponse), 'error');
                    helper.closeQuickAction();
                    return;
                }

                window.sforce.opencti.clickToDial({
                    number: phone,
                    callback: $A.getCallback(function (dialResponse) {
                        if (dialResponse && dialResponse.success === false) {
                            helper.showToast('Unable to dial from Aircall', helper.getOpenCtiErrorMessage(dialResponse), 'error');
                        } else {
                            helper.showToast('Aircall opened', 'Aircall is ready to call ' + phone + '.', 'success');
                        }

                        helper.closeQuickAction();
                    })
                });
            })
        });
    },

    normalizePhone: function (phone) {
        return phone ? phone.trim() : '';
    },

    openMobileAircallPage: function (recordId) {
        var url = this.mobileAircallPage + '?id=' + encodeURIComponent(recordId);
        var navigateToUrl = $A.get('e.force:navigateToURL');

        if (navigateToUrl) {
            navigateToUrl.setParams({
                url: url
            });
            navigateToUrl.fire();
        } else {
            window.location.href = url;
        }

        this.closeQuickAction();
    },

    getOpenCtiErrorMessage: function (response) {
        return response.errors && response.errors.length
            ? response.errors.map(function (error) {
                return error.description || error.message || error.statusCode;
            }).join(', ')
            : 'Aircall CTI could not start the call.';
    },

    showToast: function (title, message, variant) {
        var toast = $A.get('e.force:showToast');
        if (toast) {
            toast.setParams({
                title: title,
                message: message,
                type: variant
            });
            toast.fire();
        }
    },

    closeQuickAction: function () {
        var closeAction = $A.get('e.force:closeQuickAction');
        if (closeAction) {
            closeAction.fire();
        }
    }
});