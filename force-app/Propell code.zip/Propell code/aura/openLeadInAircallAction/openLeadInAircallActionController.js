({
    handleScriptsLoaded: function (component, event, helper) {
        component.set('v.scriptLoaded', true);
        helper.tryOpenAircall(component);
    },

    handleRecordUpdated: function (component, event, helper) {
        helper.tryOpenAircall(component);
    }
});