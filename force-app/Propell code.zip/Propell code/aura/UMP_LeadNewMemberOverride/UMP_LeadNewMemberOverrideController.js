({
    doInit : function(component, event, helper) {

        var navService = component.find("navService");

        navService.navigate({
            type: "standard__objectPage",
            attributes: {
                objectApiName: "Lead",
                actionName: "new"
            },
            state: {
                recordTypeId: "0121I000000UxHkQAK"
            }
        });
    }
})